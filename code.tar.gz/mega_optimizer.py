import subprocess, time, json, sqlite3, random, re, itertools
from pathlib import Path

SANDBOX = Path.home() / "quantum_lab_sandbox"
GOLDEN = SANDBOX / "GOLDEN_AI.json"
BEST_FILE = SANDBOX / "MEGA_BEST.json"
LOG = SANDBOX / ".mega.log"

# ЕДИНЫЙ шаблон: пороги + TP/SL в одном
TEMPLATE = '''import sqlite3

FEE = 0.001
LIMIT = 1000
LONG_THR = {LONG}
SHORT_THR = {SHORT}
TP_PCT = {TP}
SL_PCT = {SL}

def my_indicator(prices):
    result = [None] * len(prices)
    n = 14
    if len(prices) < n: return result
    for i in range(n - 1, len(prices)):
        window = prices[i - n + 1:i + 1]
        hh = max(window)
        ll = min(window)
        if hh == ll: result[i] = -50.0
        else: result[i] = (hh - prices[i]) / (hh - ll) * -100
    return result

def fetch(conn, sym):
    cur = conn.cursor()
    cur.execute("SELECT ts, o, h, l, c, v FROM candles WHERE symbol=? AND tf=? ORDER BY ts DESC LIMIT ?", (sym, "4h", LIMIT))
    return cur.fetchall()[::-1]

def bt(conn, sym):
    cs = fetch(conn, sym)
    if len(cs) < 30: return 0.0
    closes = [r[4] for r in cs]
    ind = my_indicator(closes)
    pos = 0
    entry = 0.0
    trades = []
    for i in range(1, len(cs)):
        if ind[i] is None or ind[i-1] is None: continue
        ind_cur = ind[i]
        cur_c = closes[i]
        high = cs[i][2]
        low = cs[i][3]
        if pos == 0 and ind_cur < LONG_THR:
            pos = 1; entry = cur_c
        elif pos == 0 and ind_cur > SHORT_THR:
            pos = -1; entry = cur_c
        if pos == 1:
            if high >= entry * (1 + TP_PCT): trades.append(TP_PCT - FEE*2); pos = 0
            elif low <= entry * (1 - SL_PCT): trades.append(-SL_PCT - FEE*2); pos = 0
        elif pos == -1:
            if low <= entry * (1 - TP_PCT): trades.append(TP_PCT - FEE*2); pos = 0
            elif high >= entry * (1 + SL_PCT): trades.append(-SL_PCT - FEE*2); pos = 0
    return sum(trades)

def main():
    conn = sqlite3.connect("data/market.db")
    total = 0.0
    for s in ["BTCUSDT","ETHUSDT","SOLUSDT","DOGEUSDT","XRPUSDT"]:
        total += bt(conn, s)
    print(f"ИТОГО: {total}")
    conn.close()

if __name__ == "__main__":
    main()
'''

def log(msg):
    ts = time.strftime("%H:%M:%S")
    line = "[" + ts + "] " + msg
    print(line, flush=True)
    try:
        with open(LOG, "a") as f:
            f.write(line + chr(10))
    except: pass

def get_pnl(out):
    for line in out.split(chr(10)):
        if "ИТОГО" in line:
            nums = re.findall(r"-?\d+\.?\d*", line)
            if nums:
                try: return float(nums[-1])
                except: pass
    return -99999.0

def test_all(long_thr, short_thr, tp, sl):
    code = (TEMPLATE
            .replace("{LONG}", str(long_thr))
            .replace("{SHORT}", str(short_thr))
            .replace("{TP}", str(tp))
            .replace("{SL}", str(sl)))
    f = SANDBOX / "tools" / "_mega_test.py"
    f.write_text(code)
    try:
        r = subprocess.run(["python3", str(f)], cwd=SANDBOX, capture_output=True, text=True, timeout=60)
        return get_pnl(r.stdout + r.stderr)
    except: return -99999.0

def main():
    log("=== MEGA OPTIMIZER (пороги + TP/SL вместе) ===")
    best_pnl = 0.582
    if GOLDEN.exists():
        try: best_pnl = json.loads(GOLDEN.read_text()).get("pnl", best_pnl)
        except: pass
    log("baseline=" + str(best_pnl))
    
    history = {}
    if BEST_FILE.exists():
        try: history = json.loads(BEST_FILE.read_text())
        except: pass
    best = history.get("best", {"pnl": best_pnl, "long": -80, "short": -20, "tp": 0.02, "sl": 0.01})
    log("current_best: " + str(best))
    
    # ПРОСТРАНСТВО ПОИСКА
    longs = [-95, -90, -85, -80, -75, -70]
    shorts = [-30, -25, -20, -15, -10]
    tps = [0.015, 0.02, 0.025, 0.03, 0.04, 0.05]
    sls = [0.0075, 0.01, 0.0125, 0.015, 0.02, 0.025]
    
    # Всего 6 × 5 × 6 × 6 = 1080 комбинаций
    log("total_combos=" + str(len(longs)*len(shorts)*len(tps)*len(sls)))
    
    iteration = 0
    while True:
        iteration += 1
        log("--- раунд " + str(iteration) + " ---")
        
        # По 20 комбинаций за раунд
        for _ in range(20):
            lt = random.choice(longs)
            st = random.choice(shorts)
            tp = random.choice(tps)
            sl = random.choice(sls)
            if lt >= st: continue
            
            key = str(lt)+"_"+str(st)+"_"+str(tp)+"_"+str(sl)
            if "tested" not in history: history["tested"] = []
            if key in history["tested"]: continue
            
            log("test L="+str(lt)+" S="+str(st)+" TP="+str(tp)+" SL="+str(sl))
            pnl = test_all(lt, st, tp, sl)
            history["tested"].append(key)
            
            if pnl > best["pnl"]:
                log("NEW_BEST " + str(pnl) + " L="+str(lt)+" S="+str(st)+" TP="+str(tp)+" SL="+str(sl))
                best = {"pnl": pnl, "long": lt, "short": st, "tp": tp, "sl": sl}
                history["best"] = best
                BEST_FILE.write_text(json.dumps(history, indent=2))
                
                # Сохраняем в GOLDEN
                final = (TEMPLATE
                         .replace("{LONG}", str(lt)).replace("{SHORT}", str(st))
                         .replace("{TP}", str(tp)).replace("{SL}", str(sl)))
                GOLDEN.write_text(json.dumps({
                    "iter": 0, "pnl": pnl, "indicator": "WILLIAMS_MEGA",
                    "long_thr": lt, "short_thr": st, "tp": tp, "sl": sl,
                    "full_code": final
                }, indent=2))
                log("SAVED_TO_GOLDEN")
            else:
                log("  worse " + str(round(pnl, 3)))
            time.sleep(1)
        
        history["best"] = best
        BEST_FILE.write_text(json.dumps(history, indent=2))
        log("раунд " + str(iteration) + " done. best=" + str(best["pnl"]))
        time.sleep(5)

if __name__ == "__main__":
    main()
