#!/usr/bin/env python3
import os, json, glob
from datetime import datetime
BASE = os.path.expanduser('~/quantum_lab')
def save_history(folder, data):
    d = os.path.join(BASE, 'data', folder); os.makedirs(d, exist_ok=True)
    ts = datetime.now().strftime('%Y-%m-%d-%H%M%S')
    path = os.path.join(d, f'{ts}.json')
    json.dump(data, open(path, 'w'), indent=2, ensure_ascii=False)
    files = sorted(glob.glob(os.path.join(d, '*.json')))
    for f in files[:-100]: os.remove(f)
    return path
def load_history(folder, n=10):
    d = os.path.join(BASE, 'data', folder)
    return [json.load(open(f)) for f in sorted(glob.glob(os.path.join(d, '*.json')))[-n:]]
if __name__ == '__main__': print('OK')
