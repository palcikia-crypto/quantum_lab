#!/usr/bin/env python3
import os
import json
import glob
from datetime import datetime

BASE = os.path.expanduser('~/quantum_lab')

def save_history(folder, data):
    d = os.path.join(BASE, 'data', folder)
    os.makedirs(d, exist_ok=True)
    ts = datetime.now().strftime('%Y-%m-%d-%H%M%S')
    path = os.path.join(d, f'{ts}.json')

    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except OSError as e:
        print(f"Error saving history to {path}: {e}")

    files = sorted(glob.glob(os.path.join(d, '*.json')))
    for f in files[:-100]:
        if os.path.exists(f):  # Проверка существования файла перед удалением
            try:
                os.remove(f)
            except OSError as e:
                print(f"Error deleting file {f}: {e}")

    return path

def load_history(folder, n=10):
    d = os.path.join(BASE, 'data', folder)
    if not os.path.exists(d):  # Проверка существования директории
        print(f"Directory {d} does not exist.")
        return []

    files = sorted(glob.glob(os.path.join(d, '*.json')))
    history = []
    for f in files[-n:]:
        if os.path.exists(f):  # Проверка существования файла перед загрузкой
            try:
                with open(f, encoding='utf-8') as file:
                    history.append(json.load(file))
            except (OSError, json.JSONDecodeError) as e:
                print(f"Error loading file {f}: {e}")

    return history

if __name__ == '__main__':
    print('OK')