#!/usr/bin/env python3
"""genetic.py — скрещивает лучших мутантов."""
import re

def parse_params(name):
    return [float(n) for n in re.findall(r'\d+\.?\d*', name)]

def mutate_mean_rev(period, threshold):
    def strat(o, h, l, c, v, ind):
        n = len(c)
        up = [False] * n
        dn = [False] * n
        if n < period:
            return up, dn
        sma = [sum(c[i-period+1:i+1]) / period for i in range(period-1)] + [sum(c[i-period+1:i+1]) / period for i in range(period-1, n)]
        std = [0] * n
        for i in range(n):
            if i >= period:
                std[i] = (sum((c[j] - sma[i]) ** 2 for j in range(i-period+1, i+1)) / period) ** 0.5
        for i in range(period, n):
            if std[i] == 0:
                continue
            z = (c[i] - sma[i]) / std[i]
            if z < -threshold:
                up[i] = True
            elif z > threshold:
                dn[i] = True
        return up, dn
    strat.__name__ = f"mean_rev_{period}_{threshold}"
    return strat

def mutate_stoch(period, lo, hi):
    def strat(o, h, l, c, v, ind):
        n = len(c)
        up = [False] * n
        dn = [False] * n
        if n < period:
            return up, dn
        for i in range(period, n):
            lo_p = min(l[i-period+1:i+1])
            hi_p = max(h[i-period+1:i+1])
            if hi_p == lo_p:
                continue
            k = 100 * (c[i] - lo_p) / (hi_p - lo_p)
            if k < lo:
                up[i] = True
            elif k > hi:
                dn[i] = True
        return up, dn
    strat.__name__ = f"stoch_{period}_{lo}_{hi}"
    return strat

def crossover(name_a,name_b):
    def strat(data):
        a = data[name_a]
        b = data[name_b]
        # crossover: a crosses over b (a was below or equal, now above)
        up = (a[-1] > b[-1]) & (a[-2] <= b[-2])
        # crossunder: a crosses under b (a was above or equal, now below)
        dn = (a[-1] < b[-1]) & (a[-2] >= b[-2])
        return up, dn
    strat.__name__ = f"cross_{name_a}_{name_b}"
    return strat