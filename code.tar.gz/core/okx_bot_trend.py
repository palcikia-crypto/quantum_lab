import os, sys, json, sqlite3, time, re
from datetime import datetime
import numpy as np
from datetime import datetime
import sqlite3
import sqlite3
import sqlite3
import time

from datetime import datetime

LOG = 'logfile.log'  # Укажите имя файла для логирования

def log(m):
    line = f'[{datetime.now():%H:%M:%S}] {m}'
    print(line, flush=True)
    with open(LOG, 'a') as f:
        f.write(line + '\n')

import sqlite3

DB = 'trades.db'

def init_db():
    c = sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol TEXT NOT NULL, 
        side TEXT NOT NULL, 
        strategy TEXT NOT NULL,
        entry_price REAL NOT NULL, 
        exit_price REAL, 
        pnl REAL,
        entry_ts INTEGER NOT NULL, 
        exit_ts INTEGER,
        status TEXT DEFAULT 'OPEN', 
        win_flag INTEGER DEFAULT 0,
        tp REAL NOT NULL, 
        sl REAL NOT NULL, 
        timeout_bars INTEGER DEFAULT 4
    )""")
    c.commit()
    c.close()

import sqlite3

def get_candles(sym, tf='15m', limit=200):
    sym_db = sym.replace('-', '')
    c = sqlite3.connect(MARKET, timeout=10)

    rows = c.execute("SELECT ts, o, h, l, c, v FROM candles WHERE symbol=? AND tf=? ORDER BY ts ASC LIMIT ?",
                     (sym_db, tf, limit)).fetchall()
    c.close()

    if not rows: 
        return None

    return {
        'ts': [r[0] for r in rows],
        'o': [r[1] for r in rows],
        'h': [r[2] for r in rows],
        'l': [r[3] for r in rows],
        'c': [r[4] for r in rows],
        'v': [r[5] for r in rows]
    }

def get_price(sym):
    d = get_candles(sym, '15m', 2)
    if d and 'c' in d and len(d['c']) > 0:
        return float(d['c'][-1])
    return None

def ema(values, period):
    """EMA."""
    if len(values) < period: return None
    alpha = 2.0 / (period + 1)
    ema_val = float(values[0])
    for v in values[1:]:
        ema_val = alpha * float(v) + (1 - alpha) * ema_val
    return ema_val

import requests

def get_candles(sym, interval, limit):
    url = f"https://api.binance.com/api/v3/klines?symbol={sym}&interval={interval}&limit={limit}"
    response = requests.get(url)

    if response.status_code != 200:
        raise Exception(f"Error fetching data: {response.status_code}")

    data = response.json()

    candles = {
        'c': [],
        'h': [],
        'l': []
    }

    for candle in data:
        candles['c'].append(float(candle[4]))  # close price
        candles['h'].append(float(candle[2]))  # high price
        candles['l'].append(float(candle[3]))  # low price

    return candles

def ema(data, period):
    if len(data) < period:
        return None
    k = 2 / (period + 1)
    ema_values = [sum(data[:period]) / period]  # Начальное значение EMA
    for price in data[period:]:
        new_ema = (price - ema_values[-1]) * k + ema_values[-1]
        ema_values.append(new_ema)
    return ema_values[-1]

def get_candles(sym, interval, limit):
    # Эта функция должна возвращать данные о свечах в виде словаря с ключами 'c', 'h', 'l'
    pass

def ema(data, period):
    if len(data) < period:
        return None
    k = 2 / (period + 1)
    ema_values = [sum(data[:period]) / period]  # Начальное значение EMA
    for price in data[period:]:
        new_ema = (price - ema_values[-1]) * k + ema_values[-1]
        ema_values.append(new_ema)
    return ema_values[-1]

def check_trend_signal(sym):
    """TREND-FOLLOWING: EMA 20/50 cross + breakout."""
    data = get_candles(sym, '15m', 200)
    if not data or len(data['c']) < 60:
        return None

    cl = data['c']
    h = data['h']
    l = data['l']

    # EMA 20/50
    ema20 = ema(cl[-20:], 20)
    ema50 = ema(cl[-50:], 50)
    if ema20 is None or ema50 is None:
        return None

    # Тренд
    trend_up = ema20 > ema50
    trend_down = ema20 < ema50

    # Breakout: последние 20 свечей
    hh = max(h[-20:-1])  # high за 20, без последней
    ll = min(l[-20:-1])   # low за 20, без последней
    cur = float(cl[-1])

    # LONG: тренд вверх + breakout вверх
    if trend_up and cur > hh:
        return ('LONG', cur)
    # SHORT: тренд вниз + breakout вниз
    if trend_down and cur < ll:
        return ('SHORT', cur)

    return None

def get_candles(symbol, timeframe, limit):
    # Здесь должна быть реализация функции получения свечей
    pass

import requests

def get_price(symbol):
    url = f"https://api.binance.com/api/v3/ticker/price?symbol={symbol}"
    try:
        response = requests.get(url)
        response.raise_for_status()  # Проверка на ошибки HTTP
        data = response.json()
        return float(data['price'])  # Возвращаем цену как число с плавающей точкой
    except requests.RequestException as e:
        print(f"Ошибка при получении цены для {symbol}: {e}")
        return None
    except ValueError:
        print(f"Ошибка при обработке данных для {symbol}.")
        return None

def log(message):
    print(message)

def close_open_trades():
    c = sqlite3.connect(DB)
    rows = c.execute("SELECT id, symbol, side, entry_price, entry_ts, strategy, tp, sl, timeout_bars FROM trades WHERE status='OPEN'").fetchall()
    now = int(time.time())

    for t_id, sym, side, ep, ets, strat, tp, sl, tb in rows:
        tp = tp or TP_DEFAULT
        sl = sl or SL_DEFAULT
        tb = int(tb or TIMEOUT_DEFAULT)
        data = get_candles(sym, '15m', 50)
        exit_p = None
        reason = None

        if data:
            for j in range(len(data['ts'])):
                if data['ts'][j] < ets:
                    continue
                hi, lo = data['h'][j], data['l'][j]

                if side == 'LONG':
                    if lo <= ep * (1 - sl):
                        exit_p = ep * (1 - sl)
                        reason = 'SL'
                        break
                    if hi >= ep * (1 + tp):
                        exit_p = ep * (1 + tp)
                        reason = 'TP'
                        break
                else:  # side == 'SHORT'
                    if hi >= ep * (1 + sl):
                        exit_p = ep * (1 + sl)
                        reason = 'SL'
                        break
                    if lo <= ep * (1 - tp):
                        exit_p = ep * (1 - tp)
                        reason = 'TP'
                        break

def main():
    init_db()
    log('=== OKX BOT TREND STARTED ===')
    while True:
        try:
            close_open_trades()
            if not os.path.exists(ACTIVE):
                log('  ⚠️ нет okx_active_trend.json'); time.sleep(30); continue
            active = json.load(open(ACTIVE)).get('pairs', {})
            log(f'active: {len(active)} пар')
            for key, cfg in active.items():
                sym = cfg.get('symbol')
                tp = cfg.get('tp', TP_DEFAULT)
                sl = cfg.get('sl', SL_DEFAULT)
                tb = cfg.get('timeout', TIMEOUT_DEFAULT)
                if not sym: continue
                sig = check_trend_signal(sym)
                if not sig: continue
                side, entry = sig
                if not entry: continue
                c = sqlite3.connect(DB)
                exists = c.execute("SELECT 1 FROM trades WHERE symbol=? AND entry_ts > ? LIMIT 1",
                                   (sym, int(time.time()) - COOLDOWN_SEC)).fetchone()
                if exists: c.close(); continue
                c.close()
                c = sqlite3.connect(DB)
                c.execute("INSERT INTO trades (symbol, side, strategy, entry_price, entry_ts, tp, sl, timeout_bars) VALUES (?,?,?,?,?,?,?,?)",
                          (sym, side, 'ema_breakout_20_50', entry, int(time.time()), tp, sl, tb))
                c.commit(); c.close()
                log(f'  🎯 {sym} {side} @ {entry:.6f} (ema_breakout TP={tp*100:.2f}% SL={sl*100:.2f}% timeout={tb}b)')
        except Exception as e:
            log(f'  ⚠️ {e}')
        time.sleep(18)