import os, sys, json, sqlite3, time
from collections import defaultdict
from datetime import datetime
from okx_scalp_strategies import SCALP_STRATEGIES
import os
from datetime import datetime
import sqlite3
import sqlite3
import time
from datetime import datetime
import os
from datetime import datetime
import sqlite3
import sqlite3

def log(msg):
    line = f'[{datetime.now():%H:%M:%S}] {msg}'
    print(line, flush=True)
    with open(os.path.join(BASE, 'logs/auto_filter_optimizer.log'), 'a') as f:
        f.write(line + '\n')

import sqlite3

OB_DB = 'your_database_path.db'  # Укажите путь к вашей базе данных

def get_pairs():
    c = None
    try:
        c = sqlite3.connect(OB_DB, timeout=10)
        rows = c.execute("SELECT DISTINCT symbol FROM orderbooks").fetchall()
        return [r[0] for r in rows]  # Извлекаем символы из каждой строки результата
    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        return []
    finally:
        if c:
            c.close()

import sqlite3

OB_DB = 'your_database_file.db'  # Замените на путь к вашей базе данных

def load_data(symbol, start_ts, end_ts):
    try:
        c = sqlite3.connect(OB_DB, timeout=10)
        obs = c.execute("""SELECT ts, best_bid, best_ask, spread, imbalance
                           FROM orderbooks WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts""",
                        (symbol, start_ts, end_ts)).fetchall()
        trades = c.execute("""SELECT ts, side, price, volume FROM trades
                              WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts""",
                           (symbol, start_ts, end_ts)).fetchall()
        swap = symbol + '-SWAP'
        fundings = c.execute("""SELECT ts, funding_rate FROM funding
                                WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts""",
                             (swap, start_ts - 3600, end_ts)).fetchall()
        c.close()
        return obs, trades, fundings
    except sqlite3.Error as e:
        print(f"SQLite error occurred: {e}")
        return [], [], []
    except Exception as e:
        print(f"Error occurred: {e}")
        return [], [], []

from collections import defaultdict

TP = 0.02  # Take Profit 2%
SL = 0.01  # Stop Loss 1%
TIMEOUT = 3600  # Timeout in seconds

def simulate(strat_fn, obs, trades, fundings, params):
    if not obs: 
        return {'n': 0, 'wins': 0, 'wr': 0, 'pnl': 0}

    obi_th = params['obi']
    fund_th = params['funding']
    press_th = params['pressure']
    spread_max = params['spread']

    trades_by_ts = defaultdict(list)
    for t in trades:
        trades_by_ts[t[0]].append(t)
    funding_by_ts = {}
    for f in fundings:
        funding_by_ts[f[0]] = f[1]

    def get_funding(ts):
        prev = None
        for fts in sorted(funding_by_ts):
            if fts <= ts: 
                prev = funding_by_ts[fts]
            else: 
                break
        return prev

    results = []
    cooldown = 0
    for i, ob in enumerate(obs):
        ts, bid, ask, spread, obi = ob
        if ts < cooldown: 
            continue
        if spread is None or spread > spread_max: 
            continue
        if obi is None: 
            continue

        price = (bid + ask) / 2
        buy = sum(t[3] for t in trades if t[1] == 'buy' and ts - 60 <= t[0] <= ts)
        sell = sum(t[3] for t in trades if t[1] == 'sell' and ts - 60 <= t[0] <= ts)
        pressure = buy - sell
        funding = get_funding(ts)

        side = strat_fn(obi, pressure, spread, price, 0)
        if not side: 
            continue

        # Фильтры
        if side == 'SHORT' and obi > obi_th: 
            continue
        if side == 'LONG' and obi < -obi_th: 
            continue
        if side == 'SHORT' and funding is not None and funding < fund_th: 
            continue
        if side == 'SHORT' and pressure > press_th: 
            continue

        entry

def main():
    log('=== AUTO FILTER OPTIMIZER ===')

    pairs = get_pairs()
    log(f'Пар: {len(pairs)}, стратегий: {len(SCALP_STRATEGIES)}')

    now = int(time.time())
    results = {}

    # ТОЛЬКО скальп-стратегии (они принимают отдельные значения, не массивы)
    SCALP_ONLY = {k: v for k, v in SCALP_STRATEGIES.items()}
    log(f'Скальп-стратегий: {len(SCALP_ONLY)}')

    for p_name, p_sec in PERIODS:
        start = now - p_sec
        for symbol in pairs:
            obs, trades, fundings = load_data(symbol, start, now)
            if not obs: continue
            for strat_name, strat_fn in SCALP_ONLY.items():
                for obi_th in OBI_GRID:
                    for fund_th in FUNDING_GRID:
                        for press_th in PRESSURE_GRID:
                            for spread_max in SPREAD_GRID:
                                params = {'obi': obi_th, 'funding': fund_th,
                                          'pressure': press_th, 'spread': spread_max}
                                res = simulate(strat_fn, obs, trades, fundings, params)
                                if res['n'] >= 5 and res['pnl'] > 0 and res['wr'] >= 55:
                                    key = (symbol, strat_name, obi_th, fund_th, press_th, spread_max)
                                    results[key] = res

    # Группируем по (symbol, strat) — выбираем лучший
    best = {}
    for key, res in results.items():
        sym, strat = key[0], key[1]
        if (sym, strat) not in best or res['pnl'] > best[(sym, strat)]['pnl']:
            best[(sym, strat)] = {
                'symbol': sym, 'strategy': strat,
                'obi': key[2], 'funding': key[3],
                'pressure': key[4], 'spread': key[5],'pnl': res['pnl'], 'trades': res['trades'],
                'risk': res['risk'], 'drawdown': res['drawdown']
            }