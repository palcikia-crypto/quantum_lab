#!/usr/bin/env python3
"""okx_mtf_trend.py — мульти-таймфрейм тренд (4H + 1H EMA стек)."""

def okx_mtf_trend():
    def f(o, h, l, c, v, ind):
        n = len(c)
        up = [False] * n
        dn = [False] * n

        if n < 200:
            return up, dn

        # 1H EMA (прокси: 4 свечи 15m = 1h)
        ema9_1h = convolve(c, [1] * (9 * 4), 9 * 4)
        ema21_1h = convolve(c, [1] * (21 * 4), 21 * 4)
        ema50_1h = convolve(c, [1] * (50 * 4), 50 * 4)

        for i in range(200, n):
            # Стек EMA: ema9 > ema21 > ema50 = тренд вверх
            if ema9_1h[i] > ema21_1h[i] > ema50_1h[i] and ema9_1h[i - 1] <= ema21_1h[i - 1]:
                up[i] = True
            elif ema9_1h[i] < ema21_1h[i] < ema50_1h[i] and ema9_1h[i - 1] >= ema21_1h[i - 1]:
                dn[i] = True

        return up, dn

    def convolve(data, kernel, kernel_size):
        result = [0] * len(data)
        for i in range(len(data)):
            for j in range(kernel_size):
                if i - j >= 0:
                    result[i] += data[i - j] * (kernel[j] / sum(kernel))
        return result

    f.__name__ = 'okx_mtf_trend'
    return f