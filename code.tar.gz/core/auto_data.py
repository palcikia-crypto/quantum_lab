#!/usr/bin/env python3
"""auto_data.py — автодокачка данных (market.db, oracle.db, orderbook.db)."""
import os
import sqlite3
import time
import subprocess
from datetime import datetime

BASE = os.path.expanduser('~/quantum_lab')

def log(msg):
    line = f'[{datetime.now():%H:%M:%S}] {msg}'
    print(line, flush=True)
    with open(os.path.join(BASE, 'logs/auto_data.log', encoding='utf-8'), 'a') as f:
        f.write(line + '\n')

def check_freshness(db, table, max_age_sec):
    try:
        c = sqlite3.connect(db, timeout=5)
        r = c.execute(f"SELECT MAX(ts) FROM {table}").fetchone()
        c.close()

        if r is not None and r[0] is not None:
            age = int(time.time()) - r[0]
            return age < max_age_sec, age
    except sqlite3.Error as e:
        log(f"Ошибка при проверке свежести базы данных: {e}")
    return False, 999999

def run_script(script):
    log_file_path = os.path.join(BASE, f'logs/{script.replace(".py", "")}.log')

    with open(log_file_path, 'a', encoding='utf-8') as log_file:
        subprocess.Popen(
            ['nice', '-n', '19', 'python3', os.path.join(BASE, 'core', script, encoding='utf-8')],
            stdout=log_file,
            stderr=subprocess.STDOUT,
            start_new_session=True
        )
    log(f'  запущен {script}')

def main():
    log('=== AUTO DATA ===')

    fresh, age = check_freshness(os.path.join(BASE, 'data/market.db'), 'candles', 2 * 3600)
    if not fresh:
        log(f'market.db устарел ({age // 60} мин) → data_manager')
        run_script('data_manager.py')
    else:
        log(f'market.db свежий ({age // 60} мин)')

    fresh, age = check_freshness(os.path.join(BASE, 'data/oracle.db'), 'regime', 300)
    if not fresh:
        log(f'oracle.db устарел ({age} сек) → перезапуск oracle')
        subprocess.run(['pkill','f', 'oracle'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        run_script('oracle_manager.py')
    else:
        log(f'oracle.db свежий ({age // 60} мин)')

    fresh, age = check_freshness(os.path.join(BASE, 'data/cache.db'), 'cache', 600)
    if not fresh:
        log(f'cache.db устарел ({age} сек) → перезапуск кэш менеджера')
        subprocess.run(['pkill', '-f', 'cache_manager'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        run_script('cache_manager.py')
    else:
        log(f'cache.db свежий ({age // 60} мин)')

    log('Проверка завершена. Все базы данных актуальны.')