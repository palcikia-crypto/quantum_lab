#!/usr/bin/env python3
"""gate.py — 7 уровней проверки стратегии.
Копия rslab2_gate.py + Sharpe/DD/Sortino/Calmar + месячная стабильность."""
import os, json, sqlite3
import numpy as np
from datetime import datetime
from strategy_pool import STRATEGIES as _POOL_STRATEGIES
STRATEGIES = dict(_POOL_STRATEGIES)
try:
    from okx_mutator import generate_mutants as _gm
    _extra = _gm()
    STRATEGIES.update(_extra)
    print(f'✅ gate: {len(STRATEGIES)} стратегий (pool {len(_POOL_STRATEGIES)} + okx {len(_extra)})')
except Exception as _e:
    print(f'⚠️ okx_mutator не подключён: {_e}')
    STRATEGIES = dict(_POOL_STRATEGIES)

BASE = os.path.expanduser('~/quantum_lab')
FEE = 0.0015  # 0.1% вход + 0.1% выход + 0.05% слиппедж
DB = os.path.join(BASE, 'data/market.db')
OUT = os.path.join(BASE, 'data/gate_results.json')

def load_candles(symbol, tf):
    c = sqlite3.connect(DB)
    rows = c.execute("SELECT ts,o,h,l,c,v FROM candles WHERE symbol=? AND tf=? ORDER BY ts", (symbol, tf)).fetchall()
    c.close()
    if not rows: return None
    return {k: np.array([r[i] for r in rows]) for i, k in enumerate(['ts','o','h','l','c','v'])}

def simulate(up, dn, o, c, start=50, model='open'):
    """model='open': entry=o[i+1], exit=c[i+2] (честно)."""
    trades = []
    hi = min(len(c)-2, len(c)) if model == 'open' else len(c)-1
    for i in range(start, hi):
        if up[i]:
            entry = o[i+1]; exit_p = c[i+2] if model == 'open' else c[i+1]
            trades.append((exit_p - entry) / entry - FEE)
        elif dn[i]:
            entry = o[i+1]; exit_p = c[i+2] if model == 'open' else c[i+1]
            trades.append((entry - exit_p) / entry - FEE)
    return trades

def sharpe(pnls):
    if len(pnls) < 2: return 0
    a = np.array(pnls)
    return float(a.mean()/a.std()*np.sqrt(252)) if a.std() > 0 else 0

def sortino(pnls):
    if len(pnls) < 2: return 0
    a = np.array(pnls); neg = a[a < 0]
    return float(a.mean()/(neg.std() if len(neg) > 0 else 1) * np.sqrt(252))

def max_dd(pnls):
    if not pnls: return 0
    cum = np.cumsum(pnls); peak = np.maximum.accumulate(cum)
    return float(abs((cum-peak).min())/max(abs(peak.max()),1)*100)

def monte_carlo(pnls, n=1000, nt=100):
    if len(pnls) < 10: return {'p95': 0, 'sharpe': 0, 'max_dd': 0}
    a = np.array(pnls); sims = [np.random.choice(a, min(nt,len(a))).sum() for _ in range(n)]
    return {'p95': float(np.percentile(sims,95)), 'p5': float(np.percentile(sims,5)),
            'sharpe': sharpe(pnls), 'max_dd': max_dd(pnls)}

def walk_forward(up, dn, o, c, split=0.7):
    n = len(c); cut = int(n*split)
    tr = simulate(up[:cut], dn[:cut], o[:cut], c[:cut])
    te = simulate(up[cut:], dn[cut:], o[cut:], c[cut:])
    return tr, te

def monthly_wr(pnls, ts, entry_ts):
    """Группирует PnL по месяцам, возвращает WR и PnL по месяцам."""
    if not pnls or not entry_ts: return []
    by_month = {}
    for pnl, t in zip(pnls, entry_ts):
        m = datetime.fromtimestamp(int(t)).strftime('%Y-%m')
        by_month.setdefault(m, []).append(pnl)
    out = []
    for m, ps in sorted(by_month.items()):
        wins = sum(1 for p in ps if p > 0)
        out.append({'month': m, 'wr': round(100*wins/len(ps),1), 'n': len(ps), 'pnl': round(sum(ps),4)})
    return out

def check_L1(pnls):
    n = len(pnls)
    if n == 0: return {'wr':0,'n':0,'p':1,'ci_lo':0,'pass':False}
    wins = sum(1 for p in pnls if p > 0); wr = 100*wins/n
    from math import sqrt, erf
    p = 0.5; se = sqrt(p*(1-p)/n) if n > 0 else 1
    z = (wins/n - p)/se if se > 0 else 0
    pval = 1 - 0.5*(1 + erf(abs(z)/sqrt(2)))
    ci_lo = wr - 1.96*sqrt(wr*(100-wr)/n) if n > 0 else 0
    return {'wr':round(wr,1),'n':n,'p':round(pval,4),'ci_lo':round(ci_lo,1),'pass': wr>=54 and n>=500 and pval<0.05 and ci_lo>50}

def check_L2(tr, te):
    if len(tr) < 10 or len(te) < 10: return {'train_wr':0,'test_wr':0,'delta':0,'pass':False}
    tr_wr = 100*sum(1 for x in tr if x>0)/len(tr)
    te_wr = 100*sum(1 for x in te if x>0)/len(te)
    delta = tr_wr - te_wr
    return {'train_wr':round(tr_wr,1),'test_wr':round(te_wr,1),'delta':round(delta,1),
            'pass': delta<3 and te_wr>=52 and len(te)>=100}

def check_L3(monthly):
    if not monthly: return {'trend_wr':0,'flat_wr':0,'pass':False}
    wrs = [m['wr'] for m in monthly]
    return {'trend_wr': round(max(wrs),1) if wrs else 0, 'flat_wr': round(min(wrs),1) if wrs else 0,
            'pass': all(w >= 52 for w in wrs)}

def check_L4(pnls):
    mc = monte_carlo(pnls)
    return {**mc, 'pass': mc['p95']>0 and mc['max_dd']<20 and mc['sharpe']>1.0}

def check_L7(monthly):
    if not monthly: return {'min_month_wr':0,'all_pos':False,'pass':False}
    return {'min_month_wr': min(m['wr'] for m in monthly),
            'all_pos': all(m['pnl']>0 for m in monthly),
            'pass': all(m['wr']>=52 for m in monthly) and all(m['pnl']>0 for m in monthly)}


def check_L8_orderbook(symbol):
    """Заглушка L8: orderbook-фильтр. Возвращает нейтральный результат."""
    return {'obi': 0.0, 'spread': 0, 'pass': True}

def run_gate(symbol, tf, strat_name, strat_fn):
    data = load_candles(symbol, tf)
    if not data or len(data['c']) < 100: return None
    o,h,l,c,v = data['o'], data['h'], data['l'], data['c'], data['v']
    ind = {}
    up, dn = strat_fn(o,h,l,c,v,ind)
    pnls = simulate(up, dn, o, c, model='open')
    tr, te = walk_forward(up, dn, o, c)
    entry_ts = [data['ts'][i] for i in range(50, min(len(c)-2, len(c))) if up[i] or dn[i]]
    monthly = monthly_wr(pnls, data['ts'], entry_ts)
    L1 = check_L1(pnls); L2 = check_L2(tr, te); L3 = check_L3(monthly); L4 = check_L4(pnls); L7 = check_L7(monthly)
    L8 = check_L8_orderbook(symbol)
    passes = [L1['pass'], L2['pass'], L3['pass'], L4['pass'], L7['pass'], L8['pass']]
    verdict = 'GOLDEN' if all(passes) else ('TRADE_NOW' if all(passes[:4]) else ('WATCH' if passes[0] and passes[1] else 'SKIP'))
    return {'symbol':symbol,'tf':tf,'strategy':strat_name,'verdict':verdict,
            'expectancy': round((sum(pnls)/len(pnls)) if pnls else 0, 5),
            'sharpe': L4.get('sharpe', 0),
            'max_dd': L4.get('max_dd', 0),
            'p95': L4.get('p95', 0),
            'score': round(sum(passes)/6*10 + max((sum(pnls)/len(pnls)) if pnls else 0, 0)*100, 2),
            'L1':L1,'L2':L2,'L3':L3,'L4':L4,'L7':L7,'L8':L8}

if __name__ == '__main__':
    import sys
    sys.path.insert(0, os.path.join(BASE, 'core'))
