#!/usr/bin/env python3
"""brain_loop.py v2 — использует brain.decide() + brain.execute().
Сам решает, сам исполняет. Цикл 60 сек."""
import os
import sys
import time
from datetime import datetime

BASE = os.path.expanduser('~/quantum_lab')
sys.path.insert(0, os.path.join(BASE, 'core'))
import brain

CHECK_INTERVAL = 60

def log(m):
    line = f'[{datetime.now():%H:%M:%S}] {m}'
    print(line, flush=True)
    log_path = os.path.join(BASE, 'logs/brain_loop.log')
    try:
        with open(log_path, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except OSError as e:
        print(f'Ошибка записи в лог: {e}', flush=True)

def main():
    log('=== BRAIN LOOP v2 STARTED ===')
    brain.init_db()
    last_exec = {}
    while True:
        try:
            state = brain.get_full_state()
            if not isinstance(state, dict):
                log(f'Неверный формат состояния: {type(state).__name__}')
                continue

            decisions = brain.decide(state)
            if not isinstance(decisions, list):
                log(f'Неверный формат решений: {type(decisions).__name__}')
                continue

            if decisions:
                log(f'решений: {len(decisions)}')
                for d in decisions:
                    if not isinstance(d, dict) or 'action' not in d or 'reason' not in d:
                        log(f'Неверный формат решения: {d}')
                        continue

                    action = d['action']
                    # антидубль: не повторять < 5 мин
                    if action in last_exec and time.time() - last_exec[action] < 300:
                        continue
                    log(f'  -> {action} ({d["reason"]})')
                    brain.execute(d)
                    last_exec[action] = time.time()
            else:
                log('всё ок, действий не нужно')
        except (KeyError, ValueError) as e:
            log(f'ERROR: {type(e).__name__}: {e}')
        except Exception as e:
            log(f'Необработанная ошибка: {type(e).__name__}: {e}')