import os, json, sqlite3, shutil, time, stat, subprocess
from datetime import datetime
from datetime import datetime
import os
import shutil
import time
import sqlite3
import sqlite3
import json
import os
import stat

from datetime import datetime

LOG = 'logfile.txt'  # Укажите путь к вашему лог-файлу

def log(msg):
    line = f'[{datetime.now():%H:%M:%S}] {msg}'
    print(line, flush=True)
    with open(LOG, 'a') as f:
        f.write(line + '\n')

import os
import shutil
import time

def backup(path):
    if os.path.exists(path):
        backup_path = f'{path}.bak.{int(time.time())}'
        shutil.copy(path, backup_path)

import sqlite3

ORACLE_DB = 'path_to_your_database.db'  # Укажите путь к вашей базе данных

def get_regimes():
    """Текущие режимы из oracle."""
    try:
        c = sqlite3.connect(ORACLE_DB, timeout=5)
        rows = c.execute("""SELECT symbol, regime, adx FROM regime
                            WHERE ts=(SELECT MAX(ts) FROM regime)""").fetchall()
        c.close()
        return {r[0]: {'regime': r[1], 'adx': r[2]} for r in rows}
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        return {}
    except Exception as e:
        print(f"An error occurred: {e}")
        return {}

import sqlite3

def get_wr(db, last_n=10):
    """WR за последние N сделок."""
    try:
        c = sqlite3.connect(db, timeout=5)
        rows = c.execute("""SELECT pnl FROM trades WHERE status='CLOSED'
                            ORDER BY exit_ts DESC LIMIT ?""", (last_n,)).fetchall()
        c.close()
        if not rows:
            return None, 0
        # Убедимся, что значения pnl корректны
        wins = sum(1 for r in rows if r[0] is not None and r[0] > 0)
        return 100.0 * wins / len(rows), len(rows)
    except Exception as e:
        print(f"Ошибка: {e}")
        return None, 0

import shutil
import os
from datetime import datetime

def backup(file_path):
    """Создает резервную копию файла."""
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"Файл '{file_path}' не найден.")

    # Получаем имя файла и его директорию
    directory, filename = os.path.split(file_path)

    # Создаем имя для резервной копии с отметкой времени
    backup_filename = f"{os.path.splitext(filename)[0]}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}{os.path.splitext(filename)[1]}"
    backup_path = os.path.join(directory, backup_filename)

    # Копируем файл
    shutil.copyfile(file_path, backup_path)
    return backup_path

import datetime

def log(message):
    """Записывает сообщение в лог."""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"{timestamp} - {message}\n"
    with open("log.txt", "a") as log_file:
        log_file.write(log_message)

import json
import os
import stat

V3_CFG = 'path/to/v3_config.json'  # Укажите правильный путь к файлу конфигурации

def log(message):
    print(message)  # Здесь можно реализовать более сложный логгер

def backup(file_path):
    # Реализуйте функцию резервного копирования
    pass

def adapt_v3(regimes, grail_regime):
    """Адаптирует v3 под текущий режим."""
    if not grail_regime or 'pairs' not in grail_regime:
        return
    try:
        with open(V3_CFG, 'r') as file:
            cur = json.load(file)

        st = os.stat(V3_CFG)
        need_restore = False
        if st.st_mode & stat.S_IWUSR == 0:
            os.chmod(V3_CFG, 0o644)
            need_restore = True

        changed = 0
        for pair, cfg in cur.get('per_pair', {}).items():
            sym = pair.replace('-', '')
            if sym not in regimes:
                continue

            current_regime = regimes[sym]['regime']

            # Маппинг: flat/trend_up/trend_down → flat/trend
            key = 'flat' if current_regime == 'flat' else 'trend'

            # Есть ли стратегия для этого режима?
            if pair in grail_regime['pairs'] and key in grail_regime['pairs'][pair]:
                new_strat = grail_regime['pairs'][pair][key]['strategy']

                # Обновляем все 3 режима (flat/trend_up/trend_down)
                for reg in ['flat', 'trend_up', 'trend_down']:
                    if cfg.get(reg, {}).get('strategy') != new_strat:
                        cfg[reg]['strategy'] = new_strat
                        changed += 1

        if changed > 0:
            backup(V3_CFG)
            with open(V3_CFG, 'w') as file:
                json.dump(cur, file, indent=2, ensure_ascii=False)
            log(f'✅ v3: обновлено {changed} стратегий (по режимам)')

        if need_restore:
            os.chmod(V3_CFG, 0o444)
    except Exception as e:
        log(f'⚠️ v3: {e}')

import os
import json
import subprocess
import time

BASE = '/path/to/your/base'  # Замените на актуальный путь
REGIME = os.path.join(BASE, 'regime.json')
DB_V3 = os.path.join(BASE, 'db_v3.json')
DB_V4 = os.path.join(BASE, 'db_v4.json')

def log(message):
    print(message)  # Замените на вашу функцию логирования

def get_regimes():
    # Реализуйте логику для получения режимов
    return []  # Заглушка

def get_wr(db_path, period):
    # Реализуйте логику для получения win rate
    return None, 0  # Заглушка

def main():
    log('=== AUTO ADAPT REALTIME ===')

    regimes = get_regimes()
    if not regimes:
        log('⚠️ нет данных из oracle')
        return

    # Загружаем граали по режимам
    grail_regime = None
    if os.path.exists(REGIME):
        try:
            with open(REGIME) as f:
                grail_regime = json.load(f)
        except json.JSONDecodeError:
            log('⚠️ Ошибка чтения файла regime.json')

    # Проверяем WR v3
    wr_v3, n_v3 = get_wr(DB_V3, 10)
    log(f'v3: WR={wr_v3:.1f}% ({n_v3} сделок)' if wr_v3 is not None else 'v3: нет данных')

    wr_v4, n_v4 = get_wr(DB_V4, 10)
    log(f'v4: WR={wr_v4:.1f}% ({n_v4} сделок)' if wr_v4 is not None else 'v4: нет данных')

    # Если WR < 40% — запускаем auto_evolve_by_regime немедленно
    if wr_v3 is not None and wr_v3 < 40 and n_v3 >= 10:
        log('❌ v3 WR < 40% → запускаем auto_evolve_by_regime')
        try:
            subprocess.Popen(
                ['nice', '-n', '19', 'python3', os.path.join(BASE, 'core/auto_evolve_by_regime.py')],
                stdout=open(os.path.join(BASE,'logs', 'auto_evolve_by_regime.log'), 'a'),
                stderr=subprocess.STDOUT
            )
        except Exception as e:
            log(f'⚠️ Ошибка при запуске auto_evolve_by_regime: {e}')
        else:
            log('✅ auto_evolve_by_regime успешно запущен')
    else:
        log('✅ Условия для запуска auto_evolve_by_regime не выполнены')

# Дополнительная логика для обработки других условий
if v3 is None:
    log('❌ v3 не определен, дальнейшая обработка невозможна')
elif wr_v3 >= 40:
    log('✅ v3 WR >= 40%, продолжаем наблюдение')
else:
    log('❓ Неизвестная ошибка, проверьте логи для получения дополнительной информации')

# Завершаем текущий процесс или функцию
log('🔚 Завершение текущего процесса')