import os, sys, json, sqlite3, time
import numpy as np
from collections import defaultdict
from datetime import datetime
from okx_mutator import generate_mutants
from strategy_mutations import generate_mutations

import os
from datetime import datetime

BASE = os.getcwd()  # Замените на нужный путь, если необходимо

def log(msg):
    line = f'[{datetime.now():%H:%M:%S}] {msg}'
    print(line, flush=True)
    with open(os.path.join(BASE, 'logs/auto_evolve_by_regime.log'), 'a') as f:
        f.write(line + '\n')

import sqlite3

def load_candles(sym, start_ts, end_ts, tf='15m'):
    c = sqlite3.connect(MARKET_DB, timeout=30)
    rows = c.execute("""SELECT ts, o, h, l, c, v FROM candles
                        WHERE symbol=? AND tf=? AND ts>=? AND ts<? ORDER BY ts""",
                     (sym, tf, start_ts, end_ts)).fetchall()
    c.close()
    if not rows:
        return None
    return {k: [r[i] for r in rows] for i, k in enumerate(['ts', 'o', 'h', 'l', 'c', 'v'])}

def calc_adx_at(data, idx):
    """ADX на индексе idx (упрощённо)."""
    if idx < 50: return 0
    c = data['c'][:idx+1]
    h = data['h'][:idx+1]
    l = data['l'][:idx+1]
    plus_dm = np.maximum(np.diff(h), 0)
    minus_dm = np.maximum(-np.diff(l), 0)
    tr = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    if len(tr) < 14: return 0
    plus_di = 100 * np.mean(plus_dm[-14:]) / (np.mean(tr[-14:]) + 1e-9)
    minus_di = 100 * np.mean(minus_dm[-14:]) / (np.mean(tr[-14:]) + 1e-9)
    dx = 100 * np.abs(plus_di - minus_di) / (plus_di + minus_di + 1e-9)
    return dx

def sim_trades_regime(up, dn, o, h, l, c, ts, regime_filter='flat', adx_threshold=25, tp=TP, sl=SL, timeout=TIMEOUT, start=50):
    """Симуляция с фильтром по режиму."""
    trades = []
    n = len(c)
    if n < start+2: return trades
    i = start; last_i = -1
    # Предвычисляем ADX для каждого бара
    adx_arr = np.zeros(n)
    for k in range(start, n):
        adx_arr[k] = calc_adx_at({'c': c, 'h': h, 'l': l}, k)

    while i < n - 1:
        if i <= last_i: i += 1; continue
        # Фильтр по режиму
        is_flat = adx_arr[i] < adx_threshold
        if regime_filter == 'flat' and not is_flat: i += 1; continue
        if regime_filter == 'trend' and is_flat: i += 1; continue

        side = None
        if up[i]: side = 'LONG'
        elif dn[i]: side = 'SHORT'
        if not side: i += 1; continue
        entry = c[i]
        tp_p = entry*(1+tp) if side=='LONG' else entry*(1-tp)
        sl_p = entry*(1-sl) if side=='LONG' else entry*(1+sl)
        end = min(i+1+timeout, n); exit_p = None
        for j in range(i+1, end):
            if side == 'LONG':
                if l[j] <= sl_p: exit_p = sl_p; break
                if h[j] >= tp_p: exit_p = tp_p; break
            else:
                if h[j] >= sl_p: exit_p = sl_p; break
                if l[j] <= tp_p: exit_p = tp_p; break
        if exit_p is None:
            jj = min(i+timeout, n-1); exit_p = c[jj]; last_i = jj
        else:
            last_i = i
        move = (exit_p - entry)/entry if side=='LONG' else (entry - exit_p)/entry
        pnl = (move - FEE) * 100
        trades.append({'pnl': float(pnl)})
        i += 1
    return trades

def main():
    log('=== AUTO EVOLVE BY REGIME ===')
    muts = generate_mutants()
    # 50 стратегий: все vwap, ema, grid, macd
    all_muts = {k: v for k, v in muts.items() if any(x in k for x in ['vwap', 'ema', 'grid_sma', 'macd'])}
    log(f'Стратегий (50): {len(all_muts)}')

    now = int(time.time())
    results = {'flat': defaultdict(dict), 'trend': defaultdict(dict)}

    for p_name, p_sec in PERIODS:
        start_ts = now - p_sec
        for sym in PAIRS:
            data = load_candles(sym, start_ts, now)
            if not data: continue
            for strat_name, strat_fn in all_muts.items():
                try:
                    up, dn = strat_fn(data['o'], data['h'], data['l'], data['c'], data['v'], {})
                except:
                    continue
                # Flat
                trades = sim_trades_regime(up, dn, data['o'], data['h'], data['l'], data['c'], data['ts'], 'flat')
                if trades:
                    n = len(trades); wins = sum(1 for t in trades if t['pnl'] > 0)
                    results['flat'][(sym, strat_name)][p_name] = {'n': n, 'wr': 100*wins/n, 'pnl': sum(t['pnl'] for t in trades)}
                # Trend
                trades = sim_trades_regime(up, dn, data['o'], data['h'], data['l'], data['c'], data['ts'], 'trend')
                if trades:
                    n = len(trades); wins = sum(1 for t in trades if t['pnl'] > 0)
                    results['trend'][(sym, strat_name)][p_name] = {'n': n, 'wr': 100*wins/n, 'pnl': sum(t['pnl'] for t in trades)}

    out = {'updated_at': datetime.now().isoformat(), 'source': 'auto_evolve_by_regime', 'pairs': {}}

    for regime in ['flat', 'trend']:
        best_by_pair = defaultdict(list)
        for (sym, strat), periods in results[regime].items():
            if len(periods) < 2: continue
            if all(r['n'] >= MIN_N and r['pnl'] >= MIN_PNL for r in periods.values()):
                min_pnl = min(r['pnl'] for r in periods.values())
                best_by_pair[sym].append({'strat': strat, 'min_pnl': min_pnl, 'wr': sum(r['wr'] for r in periods.values())/3})
        for sym, items in best_by_pair.items():
            items.sort(key=lambda x: -x['min_pnl'])
            top = items[0]
            sym_dash = sym[:-4] + '-USDT'
            if sym_dash not in out['pairs']:
                out['pairs'][sym_dash] = {}
            out['pairs'][sym_dash][regime] = {'strategy': top['strat'], 'min_pnl': round(top['min_pnl'], 2), 'wr': round(top['wr'], 1)}

    json.dump(out, open(OUT, 'w'), indent=2, ensure_ascii=False)
    log(f'✅ holy_grail_regime: {len(out["pairs"])} пар')

    for p, regs in out['pairs'].items():
        for r, c in regs.items():
            log(f'  {p:12s} {r:6s} -> {c["strategy"]:25s} min_pnl={c["min_pnl"]:+.2f} WR={c["wr"]:.1f}%')

    # Копия
    os.makedirs(GRAALS_DIR, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    json.dump(out, open(os.path.join(GRAALS_DIR, f'regime_{stamp}.json'), 'w'), indent=2, ensure_ascii=False)

    log('=== DONE ===')