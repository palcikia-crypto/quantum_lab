#!/usr/bin/env python3
"""okx_gate.py — гейт для OKX: прогоняет стратегии на свечах из okx.db."""
import os
import sys
import sqlite3
import json
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

BASE = os.path.expanduser('~/quantum_lab')
DB = os.path.join(BASE, 'data/okx.db')
OUT = os.path.join(BASE, 'data/okx_gate.json')

def load_candles(symbol='BTC-USDT', tf='15m'):
    c = sqlite3.connect(DB)
    rows = c.execute("SELECT ts,o,h,l,c,v FROM candles WHERE symbol=? AND tf=? ORDER BY ts", (symbol, tf)).fetchall()
    c.close()
    if len(rows) < 100: 
        return None
    return {k: [r[i] for r in rows] for i, k in enumerate(['ts', 'o', 'h', 'l', 'c', 'v'])}

def simulate(up, dn, o, c, start=20, fee=0.001):
    trades = []
    hi = min(len(c)-1, len(c))
    for i in range(start, hi):
        if up[i]:
            entry = o[i+1] if i+1 < len(o) else c[i]
            exit_p = c[i+1] if i+1 < len(c) else c[i]
            trades.append((exit_p - entry) / entry - fee)
        elif dn[i]:
            entry = o[i+1] if i+1 < len(o) else c[i]
            exit_p = c[i+1] if i+1 < len(c) else c[i]
            trades.append((entry - exit_p) / entry - fee)
    return trades

def check_l1(pnls):
    n = len(pnls)
    if n < 50: 
        return {'wr': 0, 'n': n, 'pass': False}
    wins = sum(1 for p in pnls if p > 0)
    wr = 100 * wins / n
    return {'wr': round(wr, 1), 'n': n, 'pass':True if wr >= 50 else False}

def analyze_trades(trades):
    if not trades:
        return {'average_pnl': 0, 'total_trades': 0}
    
    total_pnl = sum(trades)
    average_pnl = total_pnl / len(trades)
    
    return {'average_pnl': round(average_pnl, 2), 'total_trades': len(trades)}

def main():
    # Example entry and exit prices for trades
    entries = [100, 150, 200]
    exits = [110, 140, 210]
    fee = 1.0
    
    trades = []
    for entry, exit in zip(entries, exits):
        trades.extend(calculate_trade(entry, exit, fee))
    
    pnls = [trade for trade in trades]
    
    l1_results = check_l1(pnls)
    analysis_results = analyze_trades(trades)
    
    print("L1 Results:", l1_results)
    print("Trade Analysis:", analysis_results)

if __name__ == "__main__":
    main()