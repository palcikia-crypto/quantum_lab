import os, sys, json, sqlite3, time, pickle
import numpy as np
from datetime import datetime
from datetime import datetime
import sqlite3
import sqlite3
from datetime import datetime
import sqlite3
import sqlite3
import math
import time
import random
from collections import defaultdict

from datetime import datetime

LOG = 'logfile.log'  # Укажите путь к файлу лога

def log(msg):
    line = f'[{datetime.now():%H:%M:%S}] {msg}'
    print(line, flush=True)
    with open(LOG, 'a') as f:
        f.write(line + '\n')

import sqlite3

MARKET_DB = 'your_database_path.db'  # Замените на путь к вашей базе данных

def load_candles(sym, start_ts, end_ts, tf='15m'):
    c = sqlite3.connect(MARKET_DB, timeout=30)
    try:
        rows = c.execute("""SELECT ts, o, h, l, c, v FROM candles
                            WHERE symbol=? AND tf=? AND ts>=? AND ts<? ORDER BY ts""",
                         (sym, tf, start_ts, end_ts)).fetchall()
    finally:
        c.close()

    if not rows:
        return None

    return {k: [r[i] for r in rows] for i, k in enumerate(['ts', 'o', 'h', 'l', 'c', 'v'])}

import sqlite3

def load_orderbook(sym, start_ts, end_ts, OB_DB):
    # Проверяем, что символ заканчивается на 'USDT' и преобразуем его
    sym_dash = sym[:-4] + '-USDT' if sym.endswith('USDT') else sym

    # Подключаемся к базе данных
    c = sqlite3.connect(OB_DB, timeout=30)

    try:
        # Загружаем данные из таблицы orderbooks
        obs = c.execute("""SELECT ts, imbalance, spread FROM orderbooks
                           WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts""",
                        (sym_dash, start_ts, end_ts)).fetchall()

        # Формируем символ для funding
        swap = sym_dash + '-SWAP'

        # Загружаем данные из таблицы funding
        fundings = c.execute("""SELECT ts, funding_rate FROM funding
                                WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts""",
                             (swap, start_ts, end_ts)).fetchall()

        # Загружаем данные из таблицы trades
        trades = c.execute("""SELECT ts, side, volume FROM trades
                              WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts""",
                           (sym_dash, start_ts, end_ts)).fetchall()
    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        obs, fundings, trades = [], [], []
    finally:
        # Закрываем соединение с базой данных
        c.close()

    return obs, fundings, trades

def build_features(data, obi_by_ts, funding_by_ts, trades, TP=0.02, SL=0.01):
    X = []
    y = []
    for idx in range(60, len(data['c']) - 2):
        ts = int(data['ts'][idx])
        price = data['c'][idx]

        # Получаем значение OBI и spread
        obi_val = None
        spread_val = None
        for ots in sorted(obi_by_ts.keys(), reverse=True):
            if ots <= ts:
                obi_val = obi_by_ts[ots]['obi']
                spread_val = obi_by_ts[ots]['spread']
                break

        # Получаем значение funding
        fund_val = None
        for fts in sorted(funding_by_ts.keys(), reverse=True):
            if fts <= ts:
                fund_val = funding_by_ts[fts]
                break

        # Рассчитываем давление
        buy = sum(v for tts, side, v in trades if side == 'buy' and ts - 60 <= tts <= ts)
        sell = sum(v for tts, side, v in trades if side == 'sell' and ts - 60 <= tts <= ts)
        pressure = buy - sell

        # Рассчитываем целевую переменную
        future_price = data['c'][min(idx + 2, len(data['c']) - 1)]
        move = (future_price - price) / price

        if move >= TP:
            target = 1
        elif move <= -SL:
            target = 0
        else:
            continue  # Пропускаем итерацию, если цена не достигла TP или SL

        # Добавляем данные в X и y
        X.append([
            obi_val if obi_val is not None else 0,
            fund_val if fund_val is not None else 0,
            pressure,
            spread_val if spread_val is not None else 0
        ])
        y.append(target)

    return X, y

import math

def sigmoid(z):
    # Ограничиваем значения z для предотвращения переполнения
    z_clipped = max(-500, min(500, z))
    return 1.0 / (1.0 + math.exp(-z_clipped))

def train_logreg(X, y, lr=0.01, epochs=1000, reg=0.01):
    n, m = X.shape
    mean = X.mean(axis=0)
    std = X.std(axis=0) + 1e-9
    Xn = (X - mean) / std
    Xb = np.hstack([np.ones((n, 1)), Xn])
    w = np.zeros(Xb.shape[1])
    for _ in range(epochs):
        z = Xb @ w
        p = sigmoid(z)
        grad = (Xb.T @ (p - y)) / n
        grad[1:] += reg * w[1:]
        w -= lr * grad
    return w, mean, std

def predict(w, mean, std, X):
    Xn = (X - mean) / std
    Xb = np.hstack([np.ones((Xn.shape[0], 1)), Xn])
    return sigmoid(Xb @ w)

def log(message):
    print(message)

import requests
from datetime import datetime

def load_candles(sym, start, end):
    url = f'https://api.example.com/candles?symbol={sym}&start={start}&end={end}'
    response = requests.get(url)

    if response.status_code == 200:
        candles = response.json()
        formatted_candles = []

        for candle in candles:
            timestamp = datetime.fromtimestamp(candle['timestamp'])
            open_price = candle['open']
            high_price = candle['high']
            low_price = candle['low']
            close_price = candle['close']
            volume = candle['volume']

            formatted_candles.append({
                'timestamp': timestamp,
                'open': open_price,
                'high': high_price,
                'low': low_price,
                'close': close_price,
                'volume': volume
            })

        return formatted_candles
    else:
        print(f"Error loading candles: {response.status_code}")
        return []

# Пример вызова функции
# candles = load_candles("BTCUSDT", "2023-01-01", "2023-01-31")

def load_orderbook(sym, start, end):
    # Здесь должен быть ваш код для загрузки данных ордербука
    return [], [], []

def build_features(data, obi_by_ts, funding_by_ts, ob_trades):
    features = []
    targets = []

    for i in range(len(data)):
        feature = {}

        # Пример добавления признаков
        feature['open'] = data[i]['open']
        feature['high'] = data[i]['high']
        feature['low'] = data[i]['low']
        feature['close'] = data[i]['close']

        # Добавляем OBI и funding
        if i in obi_by_ts:
            feature['obi'] = obi_by_ts[i]
        else:
            feature['obi'] = None

        if i in funding_by_ts:
            feature['funding'] = funding_by_ts[i]
        else:
            feature['funding'] = None

        # Добавляем торговые сигналы
        if i in ob_trades:
            feature['trade_signal'] = ob_trades[i]
        else:
            feature['trade_signal'] = None

        features.append(feature)

        # Целевая переменная: например, рост цены на 2%
        if i < len(data) - 1:
            target = 1 if data[i + 1]['close'] >= data[i]['close'] * 1.02 else 0
            targets.append(target)

    return features, targets

import math

def sigmoid(z):
    return 1 / (1 + math.exp(-z))

def predict(weights, X):
    z = weights[0]  # bias term
    for i in range(len(X)):
        z += weights[i + 1] * X[i]
    return sigmoid(z)

def compute_cost(weights, X, y):
    total_cost = 0
    for i in range(len(y)):
        prediction = predict(weights, X[i])
        total_cost += y[i] * math.log(prediction) + (1 - y[i]) * math.log(1 - prediction)
    return -total_cost / len(y)

def gradient_descent(X, y, weights, learning_rate, iterations):
    m = len(y)
    for _ in range(iterations):
        weights_gradient = [0] * len(weights)
        for i in range(m):
            prediction = predict(weights, X[i])
            error = prediction - y[i]
            weights_gradient[0] += error  # bias gradient
            for j in range(len(X[i])):
                weights_gradient[j + 1] += error * X[i][j]

        for j in range(len(weights)):
            weights[j] -= (learning_rate / m) * weights_gradient[j]

    return weights

def train_logreg(X_train, y_train, learning_rate=0.01, iterations=1000):
    num_features = len(X_train[0])
    weights = [0] * (num_features + 1)  # +1 for bias term

    # Train the model using gradient descent
    weights = gradient_descent(X_train, y_train, weights, learning_rate, iterations)

    # Return the trained weights
    return weights, compute_cost(weights, X_train, y_train), 1  # The last value is a placeholder for a status code

import random

def predict(w, mean, std, X_test):
    predictions = []
    for x in X_test:
        # Вычисляем вероятность на основе линейной комбинации
        linear_combination = sum(w[i] * (x[i] - mean[i]) / std[i] for i in range(len(w)))
        # Применяем сигмоидальную функцию для получения вероятности
        probability = 1 / (1 + random.exp(-linear_combination))
        predictions.append(probability)
    return predictions

import time

PERIOD = 3600  # пример значения периода
PAIRS = ['BTCUSD', 'ETHUSD']  # пример валютных пар

def log(message):
    print(message)

def load_candles(sym, start, now):
    # Эта функция должна загружать данные по свечам
    # Возвращает список данных или пустой список
    return []

def load_orderbook(sym, start, now):
    # Эта функция должна загружать данные книги ордеров
    # Возвращает три списка: ob_obs, ob_fundings, ob_trades
    return [], [], []

def build_features(data, obi_by_ts, funding_by_ts, ob_trades):
    # Эта функция должна строить признаки X и целевую переменную y
    # Возвращает X и y
    return [], []

def main():
    log('=== ML SCALP (TP 0.15%) ===')
    now = int(time.time())
    start = now - PERIOD

    all_X = []
    all_y = []

    for sym in PAIRS:
        data = load_candles(sym, start, now)
        if not data: 
            continue

        ob_obs, ob_fundings, ob_trades = load_orderbook(sym, start, now)
        obi_by_ts = {ts: {'obi': obi, 'spread': spread} for ts, obi, spread in ob_obs if obi is not None}
        funding_by_ts = {ts: fr for ts, fr in ob_fundings}

        X, y = build_features(data, obi_by_ts, funding_by_ts, ob_trades)
        log(f'{sym}: {len(X)} примеров (LONG={sum(y)}, SHORT={len(y)-sum(y)})')

        all_X.extend(X)
        all_y.extend(y)

    if not all_X:
        log('❌ нет данных')
        return

# Вызов основной функции
if __name__ == "__main__":
    main()