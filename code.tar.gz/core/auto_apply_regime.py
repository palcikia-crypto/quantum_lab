#!/usr/bin/env python3
"""auto_apply_regime.py — внедрение стратегий по режимам в v3 (с защитой 444)."""
import os, json, shutil, time, stat
from datetime import datetime

BASE = os.path.expanduser('~/quantum_lab')
REGIME = os.path.join(BASE, 'data/holy_grail_regime.json')
V3 = os.path.join(BASE, 'data/okx_tpsl_v3.json')

def log(msg):
    line = f'[{datetime.now():%H:%M:%S}] {msg}'
    print(line, flush=True)
    with open(os.path.join(BASE, 'logs/auto_apply_regime.log'), 'a', encoding='utf-8') as f:
        f.write(line + '\n')

def backup(path):
    if os.path.exists(path):
        shutil.copy(path, f'{path}.bak.{int(time.time())}')

def main():
    log('=== AUTO APPLY REGIME ===')
    if not os.path.exists(REGIME):
        log('❌ holy_grail_regime.json нет')
        return

    try:
        with open(REGIME, encoding='utf-8') as f:
            data = json.load(f)
        pairs = data.get('pairs', {})
    except (json.JSONDecodeError, FileNotFoundError) as e:
        log(f'❌ {e}')
        return

    if not pairs:
        log('ℹ️ нет данных')
        return

    log(f'Пар: {len(pairs)}')

    # Проверяем защиту v3 (444)
    need_restore = False
    try:
        st = os.stat(V3)
        if st.st_mode & stat.S_IWUSR == 0:
            log('⏸️ v3 = 444 (защита) — снимаем для записи')
            os.chmod(V3, 0o644)
            need_restore = True
        else:
            need_restore = False
    except OSError as e:
        log(f'⚠️ stat v3: {e}')
        need_restore = False

    try:
        with open(V3, encoding='utf-8') as f:
            cur = json.load(f)
        backup(V3)
        count = 0
        for sym, regs in pairs.items():
            if sym not in cur.get('per_pair',[]):
                log(f'🔍 Adding new symbol: {sym}')
                cur['per_pair'].append(sym)
                count += 1
            for reg in regs:
                if reg not in cur.get('per_pair', {}).get(sym, []):
                    log(f'🔍 Adding new registration for symbol {sym}: {reg}')
                    cur.setdefault('per_pair', {}).setdefault(sym, []).append(reg)
                    count += 1

        if count > 0:
            with open(V3, 'w', encoding='utf-8') as f:
                json.dump(cur, f, ensure_ascii=False, indent=4)
            log(f'✅ Updated {count} entries in V3')

    except json.JSONDecodeError as e:
        log(f'⚠️ JSON decode error: {e}')
        need_restore = False

    except Exception as e:
        log(f'⚠️ Unexpected error: {e}')
        need_restore = False

    finally:
        if need_restore:
            log('🔄 Restoring from backup...')
            restore_backup(V3)
        else:
            log('✅ No issues detected, no restoration needed.')

log('🔚 Process completed.')