import os, sys, json, sqlite3, time, pickle
import numpy as np
from datetime import datetime
from datetime import datetime
import sqlite3
import sqlite3
import time
import sqlite3
import math
import os
import pickle
import json
from datetime import datetime

from datetime import datetime

LOG = 'log.txt'  # Укажите путь к файлу лога

def log(msg):
    line = f'[{datetime.now():%H:%M:%S}] {msg}'
    print(line, flush=True)
    with open(LOG, 'a') as f:
        f.write(line + '\n')

import sqlite3

MARKET_DB = 'your_database_path_here.db'  # Укажите путь к вашей базе данных

def load_candles(sym, limit=100, tf='15m'):
    c = sqlite3.connect(MARKET_DB, timeout=30)
    rows = c.execute("""SELECT ts, o, h, l, c, v FROM candles
                        WHERE symbol=? AND tf=? ORDER BY ts DESC LIMIT ?""",
                     (sym, tf, limit)).fetchall()
    c.close()

    if not rows:
        return None

    rows = rows[::-1]
    result = {k: [r[i] for r in rows] for i, k in enumerate(['ts', 'o', 'h', 'l', 'c', 'v'])}

    return result

import sqlite3

OB_DB = 'path_to_your_database.db'  # Замените на путь к вашей базе данных

def load_recent_obi(sym):
    # Преобразуем символ, если он заканчивается на 'USDT'
    sym_dash = sym[:-4] + '-USDT' if sym.endswith('USDT') else sym
    try:
        # Подключаемся к базе данных
        c = sqlite3.connect(OB_DB, timeout=5)
        # Выполняем запрос для получения последнего значения imbalance
        r = c.execute("""SELECT imbalance FROM orderbooks
                         WHERE symbol=? ORDER BY ts DESC LIMIT 1""", (sym_dash,)).fetchone()
    except sqlite3.Error as e:
        print(f"Ошибка при обращении к базе данных: {e}")
        return None
    finally:
        # Закрываем соединение с базой данных
        c.close()

    # Возвращаем значение imbalance, если оно существует
    return r[0] if r is not None else None

import sqlite3

OB_DB = 'your_database_path.db'  # Замените на ваш путь к базе данных

def load_recent_funding(sym):
    sym_dash = sym[:-4] + '-USDT' if sym.endswith('USDT') else sym
    swap = sym_dash + '-SWAP'

    c = sqlite3.connect(OB_DB, timeout=5)
    try:
        r = c.execute("""SELECT funding_rate FROM funding
                         WHERE symbol=? ORDER BY ts DESC LIMIT 1""", (swap,)).fetchone()
        return r[0] if r else None
    except Exception as e:
        print(f"Ошибка при загрузке данных: {e}")
        return None
    finally:
        c.close()

def load_recent_pressure(sym, window=60):
    sym_dash = sym[:-4] + '-USDT' if sym.endswith('USDT') else sym
    now = int(time.time())

    c = sqlite3.connect(OB_DB, timeout=5)

    try:
        r = c.execute("""SELECT
                            SUM(CASE WHEN side='buy' THEN volume ELSE 0 END),
                            SUM(CASE WHEN side='sell' THEN volume ELSE 0 END)
                         FROM trades WHERE symbol=? AND ts > ?""", (sym_dash, now - window)).fetchone()
    finally:
        c.close()

    if r and (r[0] is not None or r[1] is not None):
        return (r[0] if r[0] is not None else 0) - (r[1] if r[1] is not None else 0)

    return 0

def calc_adx_at(c, h, l, idx):
    if idx < 50:
        return 0

    cc = c[:idx + 1]
    hh = h[:idx + 1]
    ll = l[:idx + 1]

    plus_dm = [max(hh[i] - hh[i - 1], 0) for i in range(1, len(hh))]
    minus_dm = [max(ll[i - 1] - ll[i], 0) for i in range(1, len(ll))]

    tr = [max(hh[i] - ll[i], abs(hh[i] - cc[i - 1]), abs(ll[i] - cc[i - 1])) for i in range(1, len(hh))]

    if len(tr) < 14:
        return 0

    # Обеспечиваем, что plus_dm и minus_dm имеют достаточную длину
    plus_dm = plus_dm[-14:]
    minus_dm = minus_dm[-14:]
    tr = tr[-14:]

    plus_di = 100 * sum(plus_dm) / (sum(tr) + 1e-9)
    minus_di = 100 * sum(minus_dm) / (sum(tr) + 1e-9)

    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di + 1e-9)
    return dx

def calc_atr_at(h, l, c, idx):
    if idx < 50: return 0
    hh = h[:idx+1]; ll = l[:idx+1]; cc = c[:idx+1]
    tr = np.maximum(hh[1:] - ll[1:], np.maximum(np.abs(hh[1:] - cc[:-1]), np.abs(ll[1:] - cc[:-1])))
    return np.mean(tr[-14:])

def calc_rsi_at(c, idx, period=14):
    if idx < period:
        return 50  # Возвращаем 50, если недостаточно данных для расчета RSI

    deltas = []
    for i in range(1, idx + 1):
        deltas.append(c[i] - c[i - 1])

    gains = sum(delta for delta in deltas[-period:] if delta > 0)
    losses = -sum(delta for delta in deltas[-period:] if delta < 0)

    avg_gain = gains / period
    avg_loss = losses / period

    if avg_loss == 0:
        return 100

    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def calc_macd_at(c, idx):
    if idx < 26:
        return 0
    # Вычисляем средние значения для последних 12 и 26 периодов
    short_term_period = 12
    long_term_period = 26

    # Получаем последние 12 и 26 значений для расчета
    short_term_values = c[idx - short_term_period + 1:idx + 1]
    long_term_values = c[idx - long_term_period + 1:idx + 1]

    # Вычисляем средние значения
    short_term_average = sum(short_term_values) / len(short_term_values)
    long_term_average = sum(long_term_values) / len(long_term_values)

    # Возвращаем разницу средних значений
    return short_term_average - long_term_average

import math

def sigmoid(z):
    # Используем math.exp для вычисления экспоненты
    return 1.0 / (1.0 + math.exp(-max(-500, min(z, 500))))

from math import exp

def sigmoid(x):
    return 1 / (1 + exp(-x))

def predict(w, mean, std, X):
    Xn = [(x - mean) / std for x in X]
    Xb = [[1] + [xn] for xn in Xn]  # добавляем единичный столбец
    return [sigmoid(sum(w[j] * Xb[i][j] for j in range(len(w)))) for i in range(len(Xb))]

def log(message):
    if isinstance(message, str):
        print(message)  # Логирование сообщений
    else:
        print("Ошибка: сообщение должно быть строкой.")

import requests

def load_candles(sym, limit=100):
    url = f'https://api.binance.com/api/v3/klines?symbol={sym}&interval=4h&limit={limit}'
    response = requests.get(url)

    if response.status_code != 200:
        raise Exception(f"Error fetching data: {response.status_code}")

    candles = response.json()

    # Преобразуем данные свечей
    formatted_candles = []
    for candle in candles:
        open_time = candle[0]
        open_price = float(candle[1])
        high_price = float(candle[2])
        low_price = float(candle[3])
        close_price = float(candle[4])
        volume = float(candle[5])
        close_time = candle[6]

        formatted_candles.append({
            'open_time': open_time,
            'open': open_price,
            'high': high_price,
            'low': low_price,
            'close': close_price,
            'volume': volume,
            'close_time': close_time
        })

    return formatted_candles

import requests

def load_recent_obi(sym):
    try:
        # Пример URL для получения данных OBI (отредактируйте в соответствии с вашим API)
        url = f"https://api.example.com/obi/{sym}"
        response = requests.get(url)

        # Проверка успешности запроса
        response.raise_for_status()

        # Предполагаем, что данные приходят в формате JSON
        obi_data = response.json()

        # Вернуть необходимые данные OBI
        return obi_data

    except requests.exceptions.RequestException as e:
        print(f"Ошибка при загрузке OBI для {sym}: {e}")
        return None

import requests

def load_recent_funding(sym):
    url = f"https://api.example.com/funding/{sym}"  # Замените на реальный URL API
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        return data.get('funding_rate', 0)  # Предполагаем, что funding_rate находится в ответе
    else:
        print(f"Ошибка загрузки данных: {response.status_code}")
        return None

import requests

def load_recent_pressure(sym):
    try:
        url = f'https://api.example.com/pressure/{sym}'  # Замените на реальный API
        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()
            return data.get('pressure', None)
        else:
            print(f"Ошибка загрузки данных: {response.status_code}")
            return None
    except Exception as e:
        print(f"Произошла ошибка: {e}")
        return None

def calc_smoothed_average(data, period):
    if len(data) < period:
        return None
    return sum(data[-period:]) / period

def calc_adx_at(closes, highs, lows, idx, period=14):
    if idx < period:
        return None

    # True Range (TR) calculation
    tr_list = []
    for i in range(1, idx + 1):
        high_prev = highs[i - 1]
        low_prev = lows[i - 1]
        high_curr = highs[i]
        low_curr = lows[i]
        tr = max(high_curr - low_curr, abs(high_curr - close_prev), abs(low_prev - close_prev))
        tr_list.append(tr)

    # Calculate the smoothed True Range
    tr_smooth = calc_smoothed_average(tr_list, period)

    # Directional Movement (DM) calculation
    dm_plus = 0
    dm_minus = 0
    for i in range(1, idx + 1):
        high_curr = highs[i]
        high_prev = highs[i - 1]
        low_curr = lows[i]
        low_prev = lows[i - 1]

        if high_curr - high_prev > low_prev - low_curr and high_curr - high_prev > 0:
            dm_plus += high_curr - high_prev
        elif low_prev - low_curr > high_curr - high_prev and low_prev - low_curr > 0:
            dm_minus += low_prev - low_curr

    # Calculate the smoothed DM
    dm_plus_smooth = calc_smoothed_average([dm_plus] * period, period)
    dm_minus_smooth = calc_smoothed_average([dm_minus] * period, period)

    # Calculate the Average Directional Index (ADX)
    if tr_smooth == 0:
        return None

    pdi = 100 * (dm_plus_smooth / tr_smooth)
    mdi = 100 * (dm_minus_smooth / tr_smooth)

    adx = 100 * abs((pdi - mdi) / (pdi + mdi))

    return adx

def calc_atr_at(highs, lows, closes, idx, period=14):
    if idx < period:
        raise ValueError("Index must be greater than or equal to period")

    # Calculate True Range (TR)
    tr_values = []
    for i in range(idx - period + 1, idx + 1):
        high = highs[i]
        low = lows[i]
        close_prev = closes[i - 1] if i > 0 else closes[i]
        tr = max(high - low, abs(high - close_prev), abs(low - close_prev))
        tr_values.append(tr)

    # Calculate Average True Range (ATR)
    atr = sum(tr_values) / period
    return atr

def calc_rsi_at(closes, idx):
    # Здесь должна быть реализация расчета RSI
    pass

def calc_ema(prices, period):
    if len(prices) < period:
        return None
    k = 2 / (period + 1)
    ema_values = [sum(prices[:period]) / period]  # Начальное значение EMA
    for price in prices[period:]:
        ema = (price - ema_values[-1]) * k + ema_values[-1]
        ema_values.append(ema)
    return ema_values

def calc_macd_at(closes, idx):
    if idx < 26:  # Длина EMA12 + EMA26 + 9
        return None  # Недостаточно данных для расчета MACD

    ema12 = calc_ema(closes[:idx + 1], 12)[-1]  # EMA 12
    ema26 = calc_ema(closes[:idx + 1], 26)[-1]  # EMA 26
    macd = ema12 - ema26

    signal_line = calc_ema(closes[:idx + 1], 9)[-1]  # EMA 9 от MACD
    macd_signal = macd - signal_line

    return macd, signal_line, macd_signal

def predict(weights, mean, std, features):
    # Нормализуем входные признаки
    normalized_features = [(feature - mean) / std for feature in features]

    # Вычисляем предсказание как скалярное произведение весов и нормализованных признаков
    prediction = sum(weight * feature for weight, feature in zip(weights, normalized_features))

    return prediction

def main():
    log('=== ML PREDICT ===')
    if not os.path.exists(MODEL_PATH):
        log('❌ модель не найдена')
        return

    with open(MODEL_PATH, 'rb') as f:
        md = pickle.load(f)
    w = md['w']
    mean = md['mean']
    std = md['std']
    log(f'Модель: accuracy={md.get("accuracy", 0):.3f}, cv={md.get("cv_mean", 0):.3f}')

    preds = {}
    for sym in PAIRS:
        data = load_candles(sym, limit=100)
        if not data:
            log(f'{sym}: нет данных')
            continue
        idx = len(data['c']) - 1
        price = data['c'][idx]

        obi = load_recent_obi(sym)
        funding = load_recent_funding(sym)