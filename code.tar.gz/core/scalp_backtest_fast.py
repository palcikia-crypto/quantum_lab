import os, sys, json, sqlite3, time
from collections import defaultdict
from datetime import datetime
from scalp_strategies_v2 import SCALP_STRATEGIES_V2

import sqlite3

def q(sql, args=()):
    try:
        c = sqlite3.connect('your_database.db', timeout=10)  # замените 'your_database.db' на имя вашей базы данных
        rows = c.execute(sql, args).fetchall()
        c.commit()  # если вы вносите изменения, не забудьте зафиксировать транзакцию
        return rows
    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        return []
    finally:
        c.close()

def get_pairs():
    query_result = q("SELECT DISTINCT symbol FROM orderbooks ORDER BY symbol")
    return [r[0] for r in query_result if r]  # Проверяем, что r не пустой

def load_pair(symbol, start_ts, end_ts):
    obs = q("SELECT ts, best_bid, best_ask, spread, imbalance FROM orderbooks WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts",
            (symbol, start_ts, end_ts))
    trades = q("SELECT ts, side, price, volume FROM trades WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts",
               (symbol, start_ts, end_ts))

    # Проверяем, что оба запроса вернули данные
    if obs is None or trades is None:
        return [], []  # Возвращаем пустые списки, если данных нет

    return obs, trades

def simulate(strat_fn, obs, trades, tp, sl, timeout):
    if not obs: return {'n': 0, 'wins': 0, 'wr': 0, 'pnl': 0}
    trades_by_ts = defaultdict(list)
    for t in trades:
        trades_by_ts[t[0]].append(t)
    results = []
    cooldown = 0
    for i, ob in enumerate(obs):
        ts, bid, ask, spread, obi = ob
        if ts < cooldown: continue
        price = (bid + ask) / 2
        # pressure
        buy = sum(t[3] for t in trades if t[1]=='buy' and ts-60 <= t[0] <= ts)
        sell = sum(t[3] for t in trades if t[1]=='sell' and ts-60 <= t[0] <= ts)
        pressure = buy - sell
        side = strat_fn(obi, pressure, spread, price, 0, None)
        if not side: continue
        entry = bid if side == 'SHORT' else ask
        tp_p = entry * (1 - tp) if side == 'SHORT' else entry * (1 + tp)
        sl_p = entry * (1 + sl) if side == 'SHORT' else entry * (1 - sl)
        exit_p = None
        for j in range(i + 1, len(obs)):
            o_ts = obs[j][0]
            if o_ts - ts > timeout:
                exit_p = (obs[j][1] + obs[j][2]) / 2
                break
            for t in trades_by_ts.get(o_ts, []):
                p = t[2]
                if side == 'SHORT':
                    if p >= sl_p: exit_p = sl_p; break
                    if p <= tp_p: exit_p = tp_p; break
            if exit_p is not None: break
        if exit_p is None: continue
        move = (entry - exit_p) / entry if side == 'SHORT' else (exit_p - entry) / entry
        pnl = (move - FEE) * 100
        results.append({'pnl': round(pnl, 4)})
        cooldown = ts + timeout
    n = len(results)
    wins = sum(1 for r in results if r['pnl'] > 0)
    pnl_sum = sum(r['pnl'] for r in results)
    wr = round(100.0 * wins / n, 1) if n > 0 else 0
    return {'n': n, 'wins': wins, 'wr': wr, 'pnl': round(pnl_sum, 2)}

import os
import time
from datetime import datetime
from collections import defaultdict

# Примерные параметры, замените на свои
OUT = './output'
PERIODS = [('4H', 14400)]  # Пример: 4-часовой период
TPSL = [(0.02, 0.01, 3600)]  # TP, SL и таймаут (примерные значения)
STRATS = {
    'strategy_1': lambda obs, trades, tp, sl: {'pnl': 10, 'n': 5, 'wr': 60},  # Пример стратегии
    # Добавьте остальные стратегии
}

def get_pairs():
    # Функция для получения списка пар
    return ['BTC/USD', 'ETH/USD']  # Пример пар

def load_pair(symbol, start, end):
    # Функция для загрузки данных по паре
    # Вернуть наблюдения и торги в виде списка
    return [], []  # Замените на реальные данные

def simulate(strat_fn, obs, trades, tp, sl, timeout):
    # Функция для симуляции стратегии
    return strat_fn(obs, trades, tp, sl)

def main():
    print(f'=== FAST SCALP BACKTEST (OBI SHORT) {datetime.now():%Y-%m-%d %H:%M:%S} ===')
    now = int(time.time())
    pairs = get_pairs()
    print(f'Пар: {len(pairs)}, стратегий: {len(STRATS)}')

    all_results = {}
    for p_name, p_sec in PERIODS:
        start = now - p_sec
        for symbol in pairs:
            obs, trades = load_pair(symbol, start, now)
            if not obs: continue
            for strat_name, strat_fn in STRATS.items():
                for tp, sl, timeout in TPSL:
                    key = (p_name, symbol, strat_name, tp, sl)
                    res = simulate(strat_fn, obs, trades, tp, sl, timeout)
                    if res['n'] >= 3:
                        all_results[key] = res

    grouped = defaultdict(dict)
    for (p_name, sym, strat, tp, sl), res in all_results.items():
        grouped[(sym, strat, tp, sl)][p_name] = res