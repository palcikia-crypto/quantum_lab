#!/usr/bin/env python3
"""strategy_combinator.py — генерирует новые стратегии как комбинации существующих."""


def _call_safe(fn, o, h, l, c, v, ind):
    """Вызывает стратегию, защищаясь от деления на ноль внутри неё."""
    try:
        up, dn = fn(o, h, l, c, v, ind)
        return up, dn
    except ZeroDivisionError:
        return False, False


def combine_and(fn_a, fn_b):
    """A AND B: сигнал только если обе согласны."""
    def strat(o, h, l, c, v, ind):
        up_a, dn_a = _call_safe(fn_a, o, h, l, c, v, ind)
        up_b, dn_b = _call_safe(fn_b, o, h, l, c, v, ind)
        return up_a and up_b, dn_a and dn_b
    strat.__name__ = f"{fn_a.__name__}_AND_{fn_b.__name__}"
    return strat


def combine_or(fn_a, fn_b):
    """A OR B: сигнал если хотя бы одна."""
    def strat(o, h, l, c, v, ind):
        up_a, dn_a = _call_safe(fn_a, o, h, l, c, v, ind)
        up_b, dn_b = _call_safe(fn_b, o, h, l, c, v, ind)
        return up_a or up_b, dn_a or dn_b
    strat.__name__ = f"{fn_a.__name__}_OR_{fn_b.__name__}"
    return strat


def combine_filter(fn_a, fn_filter):
    """A + фильтр B: сигнал A, но только если B не даёт противоположный."""
    def strat(o, h, l, c, v, ind):
        up_a, dn_a = _call_safe(fn_a, o, h, l, c, v, ind)
        up_f, dn_f = _call_safe(fn_filter, o, h, l, c, v, ind)
        return up_a and not dn_f, dn_a and not up_f
    strat.__name__ = f"{fn_a.__name__}_FILTER_{fn_filter.__name__}"
    return strat


def generate_combinations(base_strategies, max_combos=30):
    """Генерирует комбинации из базовых стратегий."""
    names = list(base_strategies.keys())
    combos = {}
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if len(combos) >= max_combos:
                break
            fn_a = base_strategies[a]
            fn_b = base_strategies[b]

            combos[f"{a}_AND_{b}"] = combine_and(fn_a, fn_b)
            if len(combos) >= max_combos:
                break

            combos[f"{a}_OR_{b}"] = combine_or(fn_a, fn_b)
            if len(combos) >= max_combos:
                break

            combos[f"{a}_FILTER_{b}"] = combine_filter(fn_a, fn_b)
    return combos