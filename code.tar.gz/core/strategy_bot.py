#!/usr/bin/env python3
"""strategy_bot.py — торгует по граалям (ETH bb_15_2.5 + ETH mean_rev_15_2.5)."""
import os, sys, json, sqlite3, time
from datetime import datetime
sys.path.insert(0, os.path.join(os.path.expanduser('~/quantum_lab'), 'core'))

BASE = os.path.expanduser('~/quantum_lab')
DB = os.path.join(BASE, 'data/strategy_paper.db')
EVO = os.path.join(BASE, 'data/evolution.json')
MARKET = os.path.join(BASE, 'data/market.db')
LOG = os.path.join(BASE, 'logs/strategy_bot.log')

# TP/SL — читаются из strategy_tpsl.json (если есть), иначе defaults
_TP_DEFAULT = 0.0015
_SL_DEFAULT = 0.00075
TIMEOUT = 15 * 60
FEE = 0.001

def _load_tpsl():
    p = os.path.join(BASE, 'data/strategy_tpsl.json')
    if os.path.exists(p):
        try:
            d = json.load(open(p))
            return d.get('tp', _TP_DEFAULT), d.get('sl', _SL_DEFAULT)
        except: pass
    return _TP_DEFAULT, _SL_DEFAULT

TP, SL = _load_tpsl()

# УСКОРЕНО (E):
BET = 5.0
# TP/SL читаются из strategy_tpsl.json (см. _load_tpsl)


def log(m):
    line = f'[{datetime.now():%H:%M:%S}] {m}'
    print(line, flush=True)
    with open(LOG, 'a') as f: f.write(line + '\n')

def init_db():
    c = sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER, symbol TEXT, strategy TEXT, side TEXT,
        entry_price REAL, exit_price REAL, pnl REAL, status TEXT,
        entry_ts INTEGER, exit_ts INTEGER, tp REAL, sl REAL)""")
    c.commit(); c.close()

def get_golds():
    """Берёт ВСЕ граали, сортирует по WR (лучший первый)."""
    if not os.path.exists(EVO): return []
    try:
        d = json.load(open(EVO))
        top = d.get('top', [])
        golds = [s for s in top if s.get('wr', 0) >= 50 and s.get('n', 0) >= 100]
        # Приоритет: DOGE-грааль (WR 68.5%) — первым
        golds.sort(key=lambda x: (
            0 if x.get('symbol') == 'DOGEUSDT' and 'mean_rev_15_2.5' in x.get('strategy', '') else
            1 if x.get('symbol') == 'DOGEUSDT' else
            2 if x.get('symbol') == 'ETHUSDT' else
            3,
            -x.get('wr', 0)  # внутри группы — по WR
        ))
        return golds
    except: return []

def get_strategy_func(name, symbol):
    import strategy_pool
    for n in [name, f'sig_{name}', name.replace('.', '_'), f'sig_{name.replace(".", "_")}']:
        if hasattr(strategy_pool, n):
            return getattr(strategy_pool, n)
    try:
        import strategy_mutator, re
        nums = [float(x) for x in re.findall(r'\d+\.?\d*', name)]
        if 'bb' in name and len(nums) >= 2:
            return strategy_mutator.mutate_bb(int(nums[0]), nums[1])
        elif 'mean_rev' in name and len(nums) >= 2:
            return strategy_mutator.mutate_mean_rev(int(nums[0]), nums[1])
        elif 'stoch' in name and len(nums) >= 3:
            return strategy_mutator.mutate_stoch(int(nums[0]), nums[1], nums[2])
        elif 'ema' in name and len(nums) >= 2:
            return strategy_mutator.mutate_ema(int(nums[0]), int(nums[1]))
    except Exception as e:
        log(f'⚠️ mutator: {e}')
    return None

def get_candles(symbol, limit=100):
    c = sqlite3.connect(MARKET, timeout=10)
    rows = c.execute("SELECT ts,o,h,l,c,v FROM candles WHERE symbol=? AND tf='15m' ORDER BY ts DESC LIMIT ?", (symbol, limit)).fetchall()
    c.close()
    if not rows: return None
    rows = rows[::-1]
    return {k: [r[i] for r in rows] for i, k in enumerate(['ts','o','h','l','c','v'])}

def get_last_price(symbol):
    c = sqlite3.connect(MARKET, timeout=10)
    r = c.execute("SELECT c FROM candles WHERE symbol=? AND tf='15m' ORDER BY ts DESC LIMIT 1", (symbol,)).fetchone()
    c.close()
    return r[0] if r else None

def close_open_trades():
    c = sqlite3.connect(DB, timeout=10)
    opens = c.execute("SELECT id, symbol, side, entry_price, tp, sl, entry_ts FROM trades WHERE status='OPEN'").fetchall()
    now = int(time.time())
    for tid, sym, side, ep, tp, sl, ets in opens:
        cur = get_last_price(sym)
        if not cur: continue
        move = (cur - ep) / ep if side == 'LONG' else (ep - cur) / ep
        pnl = None; reason = None
        if move >= tp:
            pnl = BET * (tp - FEE); reason = 'TP'
        elif move <= -sl:
            pnl = -BET * (sl + FEE); reason = 'SL'
        elif now - ets > TIMEOUT:
            pnl = BET * (move - FEE); reason = 'TIMEOUT'
        if pnl is not None:
            c.execute("UPDATE trades SET status='CLOSED', exit_price=?, pnl=?, exit_ts=? WHERE id=?",
                      (cur, round(pnl, 4), now, tid))
            log(f'✅ CLOSED {sym} {side} {reason}: ${pnl:+.4f} (move={move*100:+.3f}%)')
    c.commit(); c.close()

def open_new_trades(golds):
    for gold in golds:
        sym = gold['symbol']
        strat_name = gold['strategy']
        c = sqlite3.connect(DB, timeout=10)
        exists = c.execute("SELECT 1 FROM trades WHERE symbol=? AND status='OPEN'", (sym,)).fetchone()
        c.close()
        if exists: continue
        data = get_candles(sym, 100)
        if not data or len(data['c']) < 20: continue
        func = get_strategy_func(strat_name, sym)
        if not func: continue
        try:
            ind = {}
            up, dn = func(data['o'], data['h'], data['l'], data['c'], data['v'], ind)
            if len(up) == 0 or len(dn) == 0: continue
            last_up = up[-1] if hasattr(up, '__len__') else False
            last_dn = dn[-1] if hasattr(dn, '__len__') else False
        except Exception as e:
            log(f'⚠️ {sym} {strat_name} signal: {e}')
            continue
        price = data['c'][-1]
        now = int(time.time())
        c = sqlite3.connect(DB, timeout=10)
        if last_up:
            c.execute("INSERT INTO trades (ts, symbol, strategy, side, entry_price, status, entry_ts, tp, sl) VALUES (?,?,?,'LONG',?,'OPEN',?,?,?)",
                      (now, sym, strat_name, price, now, TP, SL))
            log(f'🎯 OPEN {sym} LONG @ {price:.2f} ({strat_name})')
        elif last_dn:
            c.execute("INSERT INTO trades (ts, symbol, strategy, side, entry_price, status, entry_ts, tp, sl) VALUES (?,?,?,'SHORT',?,'OPEN',?,?,?)",
                      (now, sym, strat_name, price, now, TP, SL))
            log(f'🎯 OPEN {sym} SHORT @ {price:.2f} ({strat_name})')
        c.commit(); c.close()

def main():
    global TP, SL
    TP, SL = _load_tpsl()  # перечитываем каждый цикл
    init_db()
    golds = get_golds()
    if not golds:
        log('❌ нет граалей'); return
    top_golds = golds
    # Логируем приоритет
    priority = [g for g in top_golds if g.get('symbol') == 'DOGEUSDT']
    if priority:
        log(f"🥇 PRIORITY: DOGE {priority[0].get('strategy')} (WR={priority[0].get('wr')}%)")
    names = [f"{g['symbol'].replace('USDT','')} {g['strategy']}" for g in top_golds[:5]]
    log(f"🎯 граали (всего {len(top_golds)}): {', '.join(names)}...")
    close_open_trades()
    open_new_trades(top_golds)
    # статистика
    c = sqlite3.connect(DB)
    n, pnl, wr = c.execute("SELECT COUNT(*), ROUND(COALESCE(SUM(pnl),0),4), ROUND(100.0*SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END)/COUNT(*),1) FROM trades WHERE status='CLOSED'").fetchone()
    c.close()
    log(f'📊 PnL: {pnl} ({n} сделок, WR={wr}%)')

if __name__ == '__main__':
    import time as _t
    while True:
        try:
            main()
        except Exception as e:
            log(f'❌ ERROR: {e}')
        _t.sleep(15)
