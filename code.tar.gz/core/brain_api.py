#!/usr/bin/env python3
"""brain_api.py — HTTP API для мозга (порт 8300)."""

import os
import sys
import json
import logging
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

# Добавляем путь к проекту, где находится модуль brain
sys.path.insert(0, os.path.expanduser('~/quantum_lab/core'))
import brain

# Порт, на котором будет слушать API
PORT = 8300

# Настраиваем простой логгер (можно расширить конфигурацию при необходимости)
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
)
log = logging.getLogger(__name__)


class H(BaseHTTPRequestHandler):
    """Обработчик HTTP‑запросов."""

    # Отключаем вывод стандартных сообщений сервера (access‑log)
    def log_message(self, *args, **kwargs):
        return

    def _send(self, code: int, body, ctype: str = 'application/json; charset=utf-8') -> None:
        """Отправка HTTP‑ответа.

        Args:
            code: HTTP‑статус (200, 400, 500 и т.д.).
            body: Тело ответа – str или bytes.
            ctype: Заголовок Content‑Type.
        """
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        """Обрабатывает GET‑запросы."""
        parsed = urllib.parse.urlparse(self.path)

        try:
            # ---------- эндпоинты ----------
            if parsed.path == '/state':
                state = brain.get_full_state()
                self._send(200, json.dumps(state, ensure_ascii=False, indent=2))

            elif parsed.path == '/health':
                health = brain.health_check()
                payload = {'healthy': health['healthy'], 'issues': health['issues']}
                self._send(200, json.dumps(payload, ensure_ascii=False, indent=2))

            elif parsed.path == '/decisions':
                state = brain.get_full_state()
                decision = brain.decide(state)
                self._send(200, json.dumps(decision, ensure_ascii=False, indent=2))

            elif parsed.path == '/history':
                history = brain.get_history()
                self._send(200, json.dumps(history, ensure_ascii=False, indent=2))

            elif parsed.path == '/':
                self._send(
                    200,
                    '{"endpoints":["/state","/health","/decisions","/history"]}',
                )

            else:
                self._send(404, '{"error":"not found"}')
            # ---------- конец эндпоинтов ----------

        # ---------- известные ошибки ----------
        except (KeyError, TypeError, ValueError) as exc:
            # Ошибки, вызванные некорректными запросами или данными
            log.warning('Bad request: %s', exc)
            self._send(400, json.dumps({'error': f'Bad Request: {exc}'}))

        except json.JSONDecodeError as exc:
            # Проблемы при разборе JSON (например, в данных, получаемых из brain)
            log.error('JSON decode error: %s', exc)
            self._send(500, json.dumps({'error': f'JSON Decode Error: {exc}'}))

        except RuntimeError as exc:
            # Ошибки, связанные с внутренней логикой brain (если они выбрасываются как RuntimeError)
            log.error('Runtime error: %s', exc)
            self._send(500, json.dumps({'error': f'Internal Server Error: {exc}'}))
        # ---------- конец известных ошибок ----------
        # Прочие исключения не перехватываются здесь намеренно –
        # они пройдут наружу, и HTTPServer вернёт стандартный 500‑ответ.
        # При желании их можно добавить в лог, используя `log.exception(...)`.



if __name__ == '__main__':
    # Инициализируем хранилище мозга перед запуском сервера
    brain.init_brain_db()

    # Запуск HTTP‑сервера
    server_address = ('', PORT)
    httpd = HTTPServer(server_address, H)
    log.info('Brain API запущен на порту %d', PORT)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        log.info('Остановка сервера по запросу пользователя')
    finally:
        httpd.server_close()