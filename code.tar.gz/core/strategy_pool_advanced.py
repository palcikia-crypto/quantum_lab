import numpy as np

def calc_vwap(h, l, c, v):
    n = len(c); out = np.full(n, np.nan); cum_pv = 0; cum_v = 0
    for i in range(n):
        tp = (h[i]+l[i]+c[i])/3; cum_pv += tp*v[i]; cum_v += v[i]
        if cum_v > 0: out[i] = cum_pv/cum_v
    return out

def calc_obi(o, h, l, c, v):
    """Order Book Imbalance (упрощённо): (h-l)/(h+l)."""
    n = len(c)
    out = []
    for i in range(n):
        if h[i] + l[i] > 0:
            out.append((h[i] - l[i]) / (h[i] + l[i]))
        else:
            out.append(0)  # Можно вернуть 0 или любое другое значение, если h[i] + l[i] == 0
    return out

def calc_funding_proxy(o, h, l, c, v):
    """Funding proxy: (c - SMA20) / ATR."""
    sma = np.convolve(c, np.ones(20)/20, mode='same')
    tr = np.array([max(h[i]-l[i], abs(h[i]-c[i-1]), abs(l[i]-c[i-1])) for i in range(1, len(c))])
    atr = np.convolve(tr, np.ones(14)/14, mode='same')
    out = np.zeros(len(c))
    for i in range(20, len(c)):
        if i < len(atr) and i < len(sma) and i < len(out) and atr[i] > 0: out[i] = (c[i] - sma[i]) / atr[i]
    return out

def calc_donchian(h, l, p=20):
    n = len(h); up = np.full(n, np.nan); dn = np.full(n, np.nan)
    for i in range(p, n):
        up[i] = h[i-p+1:i+1].max(); dn[i] = l[i-p+1:i+1].min()
    return up, dn

def calc_bb_squeeze(c, p=20, k=2.0):
    n = len(c); out = np.zeros(n)
    for i in range(p, n):
        m = c[i-p+1:i+1].mean(); s = c[i-p+1:i+1].std()
        if s > 0: out[i] = (c[i]-m)/(k*s)
    return out

def calc_macd(c, fast=12, slow=26, sig=9):
    def ema(arr, p):
        k = 2 / (p + 1)
        out = [None] * len(arr)
        if len(arr) < p:
            return out  # Если данных недостаточно для EMA
        out[p - 1] = sum(arr[:p]) / p  # Начальное значение EMA
        for i in range(p, len(arr)):
            out[i] = arr[i] * k + out[i - 1] * (1 - k)
        return out

    e_fast = ema(c, fast)
    e_slow = ema(c, slow)

    # Вычисляем MACD
    macd = [None] * len(c)
    for i in range(len(c)):
        if e_fast[i] is not None and e_slow[i] is not None:
            macd[i] = e_fast[i] - e_slow[i]

    signal = ema(macd, sig)

    # Вычисляем MACD Histogram
    macd_hist = [None] * len(c)
    for i in range(len(c)):
        if macd[i] is not None and signal[i] is not None:
            macd_hist[i] = macd[i] - signal[i]

    return macd_hist

def calc_atr(h, l, c, p=14):
    n = len(c)
    tr = [0] * n

    for i in range(1, n):
        tr[i] = max(h[i] - l[i], abs(h[i] - c[i-1]), abs(l[i] - c[i-1]))

    atr = [0] * n
    atr[p-1] = sum(tr[1:p]) / (p - 1)  # Инициализация ATR на первом полном периоде

    for i in range(p, n):
        atr[i] = (atr[i-1] * (p - 1) + tr[i]) / p  # Скользящее среднее

    return atr

def calc_adx(h, l, c, p=14):
    n = len(c)
    out = [0] * n  # Инициализация списка с нулями

    for i in range(p, n):
        plus = sum(max(h[j] - h[j - 1], 0) for j in range(i - p + 1, i + 1))
        minus = sum(max(l[j - 1] - l[j], 0) for j in range(i - p + 1, i + 1))

        if plus + minus > 0:
            out[i] = 100 * abs(plus - minus) / (plus + minus)

    return out

def sig_vwap_bounce(o,h,l,c,v,ind):
    if 'vwap' not in ind: ind['vwap'] = calc_vwap(h,l,c,v)
    up = np.zeros(len(c),dtype=bool); dn = np.zeros(len(c),dtype=bool)
    vw = ind['vwap']
    for i in range(1, len(c)):
        if np.isnan(vw[i]): continue
        if c[i-1] < vw[i-1] and c[i] > vw[i]: up[i] = True
        if c[i-1] > vw[i-1] and c[i] < vw[i]: dn[i] = True
    return up, dn

def calc_obi(o, h, l, c, v):
    # Расчет OBI (Order Book Imbalance)
    obv = [0] * len(c)
    for i in range(1, len(c)):
        if c[i] > c[i - 1]:
            obv[i] = obv[i - 1] + v[i]
        elif c[i] < c[i - 1]:
            obv[i] = obv[i - 1] - v[i]
        else:
            obv[i] = obv[i - 1]
    return obv

def sig_obi_extreme(o, h, l, c, v, ind):
    if 'obi' not in ind:
        ind['obi'] = calc_obi(o, h, l, c, v)
    obi = ind['obi']
    up = [False] * len(c)
    dn = [False] * len(c)
    for i in range(1, len(c)):
        if obi[i-1] < -0.3 and obi[i] > -0.3:
            up[i] = True
        if obi[i-1] > 0.3 and obi[i] < 0.3:
            dn[i] = True
    return up, dn

def sig_funding_extreme(o,h,l,c,v,ind):
    if 'fund' not in ind: ind['fund'] = calc_funding_proxy(o,h,l,c,v)
    f = ind['fund']
    up = np.zeros(len(c),dtype=bool); dn = np.zeros(len(c),dtype=bool)
    for i in range(1, len(c)):
        if f[i-1] < -2 and f[i] > -2: up[i] = True
        if f[i-1] > 2 and f[i] < 2: dn[i] = True
    return up, dn

def calc_donchian(high, low, period):
    don_up = [None] * len(high)
    don_dn = [None] * len(low)

    for i in range(period - 1, len(high)):
        don_up[i] = max(high[i - period + 1:i + 1])
        don_dn[i] = min(low[i - period + 1:i + 1])

    return don_up, don_dn

def sig_donchian_break_adv(o, h, l, c, v, ind):
    if 'don_up' not in ind:
        ind['don_up'], ind['don_dn'] = calc_donchian(h, l, 20)

    up = [False] * len(c)
    dn = [False] * len(c)

    for i in range(1, len(c)):
        if ind['don_up'][i] is None or ind['don_dn'][i] is None:
            continue
        if c[i] > ind['don_up'][i - 1]:
            up[i] = True
        if c[i] < ind['don_dn'][i - 1]:
            dn[i] = True

    return up, dn

def calc_bb_squeeze(prices, period, num_atr):
    """Calculates the Bollinger Bands squeeze indicator."""
    if len(prices) < period:
        return []

    sma = sum(prices[-period:]) / period
    std_dev = (sum((x - sma) ** 2 for x in prices[-period:]) / period) ** 0.5
    upper_band = sma + (std_dev * num_atr)
    lower_band = sma - (std_dev * num_atr)

    return upper_band - lower_band  # Return the squeeze value

def sig_bb_squeeze_break(o, h, l, c, v, ind):
    if 'bbs' not in ind:
        ind['bbs'] = [calc_bb_squeeze(c[i:], 20, 2.0) for i in range(len(c))]

    bbs = ind['bbs']
    up = [False] * len(c)
    dn = [False] * len(c)

    for i in range(1, len(c)):
        if abs(bbs[i-1]) < 0.3 and bbs[i] > 0.3:
            up[i] = True
        if abs(bbs[i-1]) < 0.3 and bbs[i] < -0.3:
            dn[i] = True

    return up, dn

def calc_macd(c, short_window=12, long_window=26, signal_window=9):
    # Функция для вычисления MACD и MACD Histogram
    def ema(data, window):
        alpha = 2 / (window + 1)
        ema_values = [data[0]]  # Инициализация с первым значением
        for price in data[1:]:
            ema_values.append((price - ema_values[-1]) * alpha + ema_values[-1])
        return ema_values

    short_ema = ema(c, short_window)
    long_ema = ema(c, long_window)
    macd = [short - long for short, long in zip(short_ema, long_ema)]
    signal = ema(macd, signal_window)
    macd_hist = [m - s for m, s in zip(macd, signal)]
    return macd_hist

def sig_macd_hist_adv(o, h, l, c, v, ind):
    if 'macd_hist' not in ind:
        ind['macd_hist'] = calc_macd(c)

    m = ind['macd_hist']
    up = [False] * len(c)
    dn = [False] * len(c)

    for i in range(1, len(c)):
        if m[i] is None or m[i-1] is None:
            continue
        if m[i-1] < 0 and m[i] > 0:
            up[i] = True
        if m[i-1] > 0 and m[i] < 0:
            dn[i] = True

    return up, dn

def sig_vwap_reversion(o, h, l, c, v, ind):
    n = len(c)
    up = [False] * n
    dn = [False] * n

    if n < 20:
        return up, dn

    tp = [(h[i] + l[i] + c[i]) / 3 for i in range(n)]

    # Считаем VWAP
    vwap = [0] * n
    for i in range(n):
        if i < 20:
            vwap[i] = sum(tp[j] * v[j] for j in range(i + 1)) / max(sum(v[j] for j in range(i + 1)), 1e-9)
        else:
            vwap[i] = sum(tp[j] * v[j] for j in range(i - 19, i + 1)) / max(sum(v[j] for j in range(i - 19, i + 1)), 1e-9)

    for i in range(20, n):
        dev = (c[i] - vwap[i]) / vwap[i]
        if dev < -0.01:
            up[i] = True
        elif dev > 0.01:
            dn[i] = True

    return up, dn

def sig_rsi_divergence(o, h, l, c, v, ind):
    n = len(c)
    up = [False] * n
    dn = [False] * n

    if n < 30:
        return up, dn

    delta = [c[i] - c[i - 1] for i in range(1, n)]
    delta.insert(0, 0)  # prepend first element

    gain = [max(d, 0) for d in delta]
    loss = [-min(d, 0) for d in delta]

    ag = [0] * n
    al = [0] * n

    for i in range(n):
        if i < 14:
            ag[i] = sum(gain[:i + 1]) / (i + 1) if i > 0 else gain[i]
            al[i] = sum(loss[:i + 1]) / (i + 1) if i > 0 else loss[i]
        else:
            ag[i] = (ag[i - 1] * 13 + gain[i]) / 14
            al[i] = (al[i - 1] * 13 + loss[i]) / 14

    rs = [ag[i] / al[i] if al[i] > 0 else 0 for i in range(n)]
    rsi = [100 - (100 / (1 + r)) for r in rs]

    for i in range(30, n):
        if c[i] < c[i - 10] and rsi[i] > rsi[i - 10] and rsi[i] < 40:
            up[i] = True
        elif c[i] > c[i - 10] and rsi[i] < rsi[i - 10] and rsi[i] > 60:
            dn[i] = True

    return up, dn

def sig_volume_spike(o, h, l, c, v, ind):
    n = len(c)
    up = [False] * n
    dn = [False] * n

    if n < 20:
        return up, dn

    # Calculate the moving average of volume
    avg = [0] * n
    for i in range(20):
        avg[i] = sum(v[:i+1]) / (i + 1)  # Compute average for the first 20 elements
    for i in range(20, n):
        avg[i] = sum(v[i-19:i+1]) / 20  # Compute average for the rest

    for i in range(20, n):
        if v[i] > avg[i] * 2:
            if c[i] > o[i]:
                up[i] = True
            else:
                dn[i] = True

    return up, dn

def sig_atr_breakout(o, h, l, c, v, ind):
    n = len(c)
    up = [False] * n
    dn = [False] * n

    if n < 20:
        return up, dn

    tr = [0] * (n - 1)
    for i in range(1, n):
        tr[i - 1] = max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))

    atr = [0] * n
    # Calculate ATR using a simple moving average
    for i in range(14, n):
        atr[i] = sum(tr[i - 14:i]) / 14

    for i in range(20, n - 1):
        if c[i] > h[i - 1] + atr[i]:
            up[i] = True
        elif c[i] < l[i - 1] - atr[i]:
            dn[i] = True

    return up, dn