#!/usr/bin/env python3
"""alerts.py — алерты при проблемах. Пишет в logs/alerts.log + опционально Telegram."""
import os
import sys
import json
import urllib.request
from datetime import datetime

BASE = os.path.expanduser('~/quantum_lab')
sys.path.insert(0, os.path.join(BASE, 'core'))
import brain

def ensure_log_directory():
    log_dir = os.path.join(BASE, 'logs')
    os.makedirs(log_dir, exist_ok=True)

def send_alert(msg):
    ensure_log_directory()
    line = f'[{datetime.now():%H:%M:%S}] ALERT: {msg}'
    print(line, flush=True)
    with open(os.path.join(BASE, 'logs/alerts.log'), 'a') as f:
        f.write(line + '\n')
    # Telegram (если есть токен в env)
    token = os.environ.get('TG_BOT_TOKEN')
    chat = os.environ.get('TG_CHAT_ID')
    if token and chat:
        try:
            url = f'https://api.telegram.org/bot{token}/sendMessage'
            data = json.dumps({'chat_id': chat, 'text': msg}).encode()
            req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=10)
        except urllib.error.URLError as e:
            print(f"Error sending alert to Telegram: {e}", flush=True)

def check():
    h = brain.health_check()
    if not h['healthy']:
        send_alert(' | '.join(h['issues']))

if __name__ == '__main__':
    check()