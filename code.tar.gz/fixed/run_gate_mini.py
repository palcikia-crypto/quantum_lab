import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.path.expanduser('~/quantum_lab/core'))
from strategy_pool import STRATEGIES
from gate_v3 import run_gate

BASE = os.path.expanduser('~/quantum_lab')
pairs = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT']
tf = '4h'
model = 'open'
results = []

def log_error(pair, name, error):
    print(f'  {pair} {name} ERROR: {error}')

def log_result(pair, name, r):
    verdict = r['verdict'] if r else 'None'
    print(f'  {pair} {name} -> {verdict}')

def save_results_to_file(results):
    with open(f'{BASE}/data/gate_v3.json', 'w') as f:
        json.dump({'timestamp': datetime.now().isoformat(), 'summary': summary, 'results': results}, f, indent=2, ensure_ascii=False)

for pair in pairs:
    for name, fn in STRATEGIES.items():
        try:
            r = run_gate(pair, tf, name, fn, model=model, use_h1=True)
            if r and 'L1' in r and r['L1']['n'] >= 50:
                results.append(r)
            log_result(pair, name, r)
        except Exception as e:
            log_error(pair, name, str(e))

results.sort(key=lambda x: (-x['score'], -x['L1']['wr']))
summary = {v: sum(1 for r in results if r.get('verdict') == v) for v in ['GOLDEN', 'TRADE_NOW', 'WATCH', 'SKIP']}
save_results_to_file(results)

print()
print('Прогонов: ' + str(len(results)))
print('Summary: ' + str(summary))
for r in results[:10]:
    print('  ' + r['symbol'].ljust(10) + ' ' + r['strategy'].ljust(15) + ' ' + r['verdict'].ljust(10) + ' WR=' + str(r['L1']['wr']) + '% n=' + str(r['L1']['n']))