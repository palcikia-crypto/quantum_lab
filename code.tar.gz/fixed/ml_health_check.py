#!/usr/bin/env python3
import os
import json
import sys
import logging

BASE = os.path.expanduser('~/quantum_lab')
HIST = os.path.join(BASE, 'data/ml_accuracy_history.jsonl')

logging.basicConfig(level=logging.INFO)

def main() -> None:
    if not os.path.exists(HIST):
        logging.info('❌ нет истории'); return
    with open(HIST) as f:
        rows = [json.loads(l) for l in f if l.strip()]
    if len(rows) < 5:
        logging.info(f'ℹ️ мало данных ({len(rows)})'); return
    recent = rows[-10:]
    avg = sum(r['accuracy'] for r in recent) / len(recent)
    dr = sum(1 for r in recent if r['drift'])
    logging.info(f'📊 avg_acc={avg:.3f} drift={dr}')
    if avg < 0.55:
        logging.error('🚨 acc<0.55 — ПОРА ПЕРЕОБУЧАТЬ'); sys.exit(2)
    elif dr > 3:
        logging.error('🚨 drift>3 — ПОРА ПЕРЕОБУЧАТЬ'); sys.exit(3)
    else:
        logging.info('✅ модель здорова')

if __name__ == '__main__':
    main()