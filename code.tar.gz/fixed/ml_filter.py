#!/usr/bin/env python3
"""ml_filter.py — фильтр ML для v3/v4 (читает ml_predictions.json)."""
import os
import json
import time
from datetime import datetime

BASE = os.path.expanduser('~/quantum_lab')
PREDICTIONS = os.path.join(BASE, 'data/ml_predictions.json')
LOG = os.path.join(BASE, 'logs/ml_filter.log')

# Пороги
PROBA_LONG_MIN = 0.6
PROBA_SHORT_MAX = 0.4

def log(msg):
    line = f'[{datetime.now():%H:%M:%S}] {msg}'
    print(line, flush=True)
    try:
        with open(LOG, 'a') as f:
            f.write(line + '\n')
    except IOError as e:
        print(f'Ошибка записи в лог: {e}', flush=True)

def load_predictions():
    """Загружает predictions (не старше 30 мин)."""
    if not os.path.exists(PREDICTIONS):
        return {}
    try:
        with open(PREDICTIONS) as f:
            d = json.load(f)
        updated = d.get('updated_at', '')
        # Проверяем свежесть (30 мин)
        if updated:
            ts = datetime.fromisoformat(updated).timestamp()
            if time.time() - ts > 30*60:
                log(f'⚠️ predictions устарели ({int((time.time()-ts)/60)} мин)')
                return {}
        return d.get('predictions', {})
    except (IOError, json.JSONDecodeError) as e:
        log(f'Ошибка загрузки предсказаний: {e}')
        return {}

def check(sym, side):
    """Проверяет ML-фильтр для пары/стороны.
    sym: 'XRP-USDT' (с дефисом) или 'XRPUSDT'
    side: 'LONG' / 'SHORT'
    """
    preds = load_predictions()
    if not preds:
        return True, 'ML нет данных (пропускаем)'

    # Нормализуем symbol (XRP-USDT → XRPUSDT)
    sym_norm = sym.replace('-', '')

    if sym_norm not in preds:
        return True, f'ML нет {sym_norm} (пропускаем)'

    p = preds[sym_norm]
    proba = p.get