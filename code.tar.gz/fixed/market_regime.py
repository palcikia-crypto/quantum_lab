#!/usr/bin/env python3
"""market_regime.py — определение режима рынка по парам. Сводка в data/regime.json."""
import os
import json
import sys
from datetime import datetime

BASE = os.path.expanduser('~/quantum_lab')
sys.path.insert(0, os.path.join(BASE, 'core'))
import oracle

def main():
    """Основная функция для инициализации базы данных и сохранения режима рынка в файл."""
    try:
        oracle.init_db()
        regimes = oracle.get_all_regimes()
    except Exception as e:
        print(f"Ошибка при инициализации базы данных или получении режимов: {e}")
        return

    by_regime = {}
    for r in regimes:
        by_regime.setdefault(r['regime'], []).append(r['symbol'])

    out = {
        'timestamp': datetime.now().isoformat(),
        'regimes': regimes,
        'summary': by_regime
    }

    try:
        with open(os.path.join(BASE, 'data/regime.json'), 'w') as f:
            json.dump(out, f, indent=2, ensure_ascii=False)
    except IOError as e:
        print(f"Ошибка при записи в файл: {e}")
        return

    print(json.dumps(out, indent=2, ensure_ascii=False))

if __name__ == '__main__':
    main()