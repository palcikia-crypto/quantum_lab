#!/usr/bin/env python3
import json

class FileInfo:
    def __init__(self, filename, description):
        self.filename = filename
        self.description = description

class ProjectMap:
    def __init__(self):
        self.map = {
            'core': [
                FileInfo('okx_bot_paper_v4.py', 'Торговый бот v4'),
                FileInfo('brain_loop.py', 'Цикл мозга'),
                FileInfo('brain.py', 'Мозг'),
                FileInfo('ml_online_simple.py', 'Обучение ML'),
                FileInfo('ml_predict_online.py', 'Предсказание ML'),
                FileInfo('oracle.py', 'Режим рынка'),
                FileInfo('orderbook_oracle.py', 'OBI+funding'),
                FileInfo('data_manager.py', 'Свечи'),
                FileInfo('evolution.py', 'Эволюция'),
                FileInfo('auto_apply_regime.py', 'TP/SL по режиму'),
                FileInfo('auto_obi_tuner.py', 'TP/SL по OBI'),
            ],
            'data': [
                FileInfo('market.db', 'Свечи'),
                FileInfo('orderbook.db', 'OBI'),
                FileInfo('oracle.db', 'Режимы'),
                FileInfo('okx_paper_v4.db', 'Сделки v4'),
                FileInfo('ml_online.pkl', 'Модель ML'),
                FileInfo('ml_predictions_online.json', 'Предсказания'),
                FileInfo('knowledge.db', 'База знаний'),
                FileInfo('agent_dashboard.html', 'Дашборд'),
            ],
            'config': [
                FileInfo('lab.json', 'Общий конфиг'),
            ],
            'tools/agent': [
                FileInfo('agent_v3.py', 'Агент v3'),
                FileInfo('agent_v5.py', 'Агент v5'),
                FileInfo('memory.db', 'Память'),
                FileInfo('rules.json', 'Правила'),
                FileInfo('knowledge_agent.py', 'Сбор знаний'),
            ],
        }

    def to_json(self):
        return {key: {file_info.filename: file_info.description for file_info in files} for key, files in self.map.items()}

if __name__ == '__main__':
    project_map = ProjectMap()