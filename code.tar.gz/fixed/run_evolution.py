#!/usr/bin/env python3
"""run_evolution.py — эволюция стратегий (L1 grid -> L2 features -> L3 mutations)."""

import sys
import os
import json
from datetime import datetime
from full_access import load_all_strategies, load_evolution

BASE = os.path.expanduser('~/quantum_lab')
strategies = load_all_strategies()
print(f'Стратегий: {len(strategies)}')

evo = load_evolution()
if evo:
    print('evolution_old загружен')
    attributes = ['L1_grid', 'L2_features', 'L3_mutations']
    for attr in attributes:
        if hasattr(evo, attr):
            print(f'{attr} есть')
else:
    print('evolution_old НЕ загружен')

# Сохраняем отчёт
out = {
    'timestamp': datetime.now().isoformat(),
    'strategies': list(strategies.keys()),
    'evolution_loaded': evo is not None
}

try:
    with open(os.path.join(BASE, 'data/evolution_report.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f'Сохранено: evolution_report.json')
except Exception as e:
    print(f'Ошибка при сохранении отчёта: {e}')