import sqlite3

FEE = 0.001  # 0.1% комиссия
SMA_WINDOW = 20
LIMIT_CANDLES = 1000  # Берем последние 1000 свечей

def fetch_candles(conn, symbol, tf):
    try:
        cur = conn.cursor()
        # Берем ПОСЛЕДНИЕ свечи (ORDER BY ts DESC)
        cur.execute("""
            SELECT ts, o, h, l, c, v
            FROM candles
            WHERE symbol = ? AND tf = ?
            ORDER BY ts DESC
            LIMIT ?
        """, (symbol, tf, LIMIT_CANDLES))
        rows = cur.fetchall()
        return rows[::-1]  # Переворачиваем обратно (от старых к новым)
    except sqlite3.Error as e:
        print(f"Ошибка при запросе к БД для символа {symbol}: {e}")
        return []

def sma_series(prices, window):
    # Вычисление скользящей средней
    out = [None] * len(prices)
    for i in range(window - 1, len(prices)):
        out[i] = sum(prices[i - window + 1:i + 1]) / window
    return out

def backtest_symbol(conn, symbol, tf):
    candles = fetch_candles(conn, symbol, tf)
    if len(candles) < SMA_WINDOW + 2:
        return {"symbol": symbol, "trades": 0, "wins": 0, "pnl": 0.0, "wr": 0.0}

    closes = [row[4] for row in candles]  # Закрывающиеся цены
    smas = sma_series(closes, SMA_WINDOW)  # Скользящие средние

    position = 0  # 0 - нет позиции, 1 - открыта длинная позиция
    entry = 0.0  # Цена входа в позицию
    trades = []  # Список сделок
    wins = 0  # Количество выигрышных сделок

    for i in range(1, len(candles)):
        if smas[i] is None or smas[i-1] is None:
            continue

        prev_c, cur_c = closes[i-1], closes[i]
        prev_s, cur_s = sm