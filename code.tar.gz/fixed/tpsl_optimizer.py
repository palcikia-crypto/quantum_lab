#!/usr/bin/env python3
"""Анализирует PnL и меняет TP/SL."""
import os
import sqlite3
import json
import logging

BASE = os.path.expanduser('~/quantum_lab')

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def optimize():
    db = os.path.join(BASE, 'data/okx_paper_v4.db')
    if not os.path.exists(db):
        logging.warning('База данных не найдена: %s', db)
        return

    try:
        with sqlite3.connect(db) as c:
            # лучший TP/SL по PnL
            rows = c.execute("""SELECT tp, sl, SUM(pnl) pnl, COUNT(*) n
                                FROM trades WHERE status='CLOSED'
                                GROUP BY tp, sl HAVING n > 20 ORDER BY pnl DESC LIMIT 1""").fetchone()

            if rows:
                tp, sl, pnl, n = rows
                logging.info('✅ лучший TP/SL: tp=%s sl=%s pnl=%s n=%s', tp, sl, pnl, n)
                # тут можно записать в okx_tpsl_v4.json
                return {'tp': tp, 'sl': sl, 'pnl': pnl}
    except sqlite3.Error as e:
        logging.error('Ошибка при работе с базой данных: %s', e)

    return None

if __name__ == '__main__':
    optimize()