#!/usr/bin/env python3
"""run_self_evolution.py — самогенерация: комбинации + мутанты → гейт → active."""
import sys
import json
import os
import logging

sys.path.insert(0, 'core')
from strategy_pool import STRATEGIES
from strategy_combinator import generate_combinations
from strategy_mutator import generate_mutations
from gate import run_gate

BASE = os.path.expanduser('~/quantum_lab')
PAIRS = ['BTCUSDT', 'ETHUSDT']  # только 2 пары, чтобы не завис

# Настройка логирования
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')

def main():
    print('=== SELF-EVOLUTION START ===')
    combos = generate_combinations(STRATEGIES, max_combos=30)
    muts = generate_mutations(max_mutants=40)
    candidates = {**combos, **muts}
    print(f'Кандидатов: {len(candidates)} (комбо {len(combos)}, мутантов {len(muts)})')

    results = []
    for i, (name, fn) in enumerate(candidates.items()):
        for pair in PAIRS:
            try:
                r = run_gate(pair, '15m', name, fn)
                if r and r['verdict'] in ('GOLDEN', 'TRADE_NOW'):
                    results.append(r)
                    print(f"  ✅ {pair} {name}: {r['verdict']} WR={r['L1']['wr']}% score={r['score']}")
            except Exception as e:
                logging.error(f"Ошибка при обработке {pair} с {name}: {e}")
        if (i + 1) % 10 == 0:
            print(f'  ... прогресс {i + 1}/{len(candidates)}')
    print(f'Прошло гейт: {len(results)}')

    # ЗАЩИТА: сначала читаем старый active, потом добавляем
    if results:
        p = os.path.join(BASE, 'data/active_strategies.json')
        with open(p) as f:
            d = json.load(f) if os.path.exists(p) else {'pairs': {}}  # читаем СУЩЕСТВУЮЩИЙ