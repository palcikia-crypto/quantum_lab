#!/usr/bin/env python3
import os
import json
import sqlite3
import subprocess
import time
from datetime import datetime
import config_manager as cfg
import glob
import shutil

BASE = os.path.expanduser('~/quantum_lab')
LOG = os.path.join(BASE, 'logs/agent.log')

def log(m, level='INFO'):
    with open(LOG, 'a') as f:
        f.write(f'[{datetime.now():%H:%M:%S}] [{level}] {m}\n')

def heal_tpsl_v4():
    if not cfg.validate('tpsl_v4'):
        if 'tpsl_v4' in cfg.CONFIGS:
            p = cfg.CONFIGS['tpsl_v4']
            baks = sorted(glob.glob(p + '.bak.*'))
            if baks:
                shutil.copy(baks[-1], p)
                log('tpsl_v4 восстановлен')
                return True
    return False

def clean_stale_market():
    log('market.db: очистка отключена (сохраняем историю)')
    return True

def heal_ml():
    p = os.path.join(BASE, 'data/ml_predictions_online.json')
    if not os.path.exists(p):
        return False
    try:
        with open(p) as f:
            d = json.load(f)
        bad = [s for s, v in d.get('predictions', {}).items() if v['proba_long'] < 0.05 or v['proba_long'] > 0.95]
        if bad:
            log('ML насыщена — переобучаем')
            subprocess.Popen(['python3', 'core/ml_online_simple.py'], cwd=BASE, stdout=open(os.path.join(BASE, 'logs/ml_online.log'), 'a'), stderr=subprocess.STDOUT)
            return True
    except Exception as e:
        log(f'Ошибка в heal_ml: {e}', level='ERROR')
    return False

def heal_rules():
    if 'rules' in cfg.CONFIGS:
        p = cfg.CONFIGS['rules']
        try:
            with open(p) as f:
                json.load(f)
            return True
        except Exception as e:
            log(f'Ошибка при загрузке rules.json: {e}', level='ERROR')
            baks = sorted(glob.glob(p + '.bak.*'))
            if baks:
                shutil