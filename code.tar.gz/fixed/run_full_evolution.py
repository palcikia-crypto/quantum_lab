#!/usr/bin/env python3
"""run_full_evolution.py — полный цикл: feedback → auto_add → feedback."""
import sys
sys.path.insert(0, 'core')
from live_feedback import run_feedback
from auto_add import run_auto_add
import logging

logging.basicConfig(level=logging.INFO)

def main():
    logging.info('=== FULL EVOLUTION CYCLE ===')
    
    try:
        logging.info('\n--- 1. FEEDBACK ---')
        run_feedback()
    except Exception as e:
        logging.error(f'Error during feedback: {e}')
    
    try:
        logging.info('\n--- 2. AUTO-ADD ---')
        run_auto_add()
    except Exception as e:
        logging.error(f'Error during auto-add: {e}')
    
    try:
        logging.info('\n--- 3. FEEDBACK ---')
        run_feedback()
    except Exception as e:
        logging.error(f'Error during feedback: {e}')
    
    logging.info('\n✅ FULL CYCLE DONE')

if __name__ == '__main__':
    main()