#!/usr/bin/env python3
"""run_gate_all.py — gate на всех ТФ (15m + 4h). Автоматически."""
import sys
import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, List

sys.path.insert(0, os.path.expanduser('~/quantum_lab/core'))
from strategy_pool import STRATEGIES
from gate_v3 import run_gate

BASE = os.path.expanduser('~/quantum_lab')
PAIRS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT']
TFS = [('15m', 'current'), ('4h', 'open')]
RESULTS_FILE_PATH = os.path.join(BASE, 'data/gate_all.json')

# Настройка логирования
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')

def main() -> None:
    results: List[Dict[str, Any]] = []
    
    for tf, model in TFS:
        for pair in PAIRS:
            for name, fn in STRATEGIES.items():
                try:
                    r = run_gate(pair, tf, name, fn, model=model, use_h1=True)
                    if r and r['L1']['n'] >= 100:
                        results.append(r)
                        # Ранжирование по мере добавления результатов
                        results.sort(key=lambda x: (-x['score'], -x['L1']['wr']))
                except Exception as e:
                    logging.error(f"Ошибка при выполнении стратегии {name} для пары {pair} на ТФ {tf}: {e}")

    summary = {v: sum(1 for r in results if r['verdict'] == v) for v in ['GOLDEN', 'TRADE_NOW', 'WATCH', 'SKIP']}
    
    with open(RESULTS_FILE_PATH, 'w') as f:
        json.dump({'timestamp': datetime.now().isoformat(), 'summary': summary, 'results': results}, f, indent=2, ensure_ascii=False)
    
    print(f'GATE ALL: {summary}, прогонов: {len(results)}')

if __name__ == "__main__":
    main()