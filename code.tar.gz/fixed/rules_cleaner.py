#!/usr/bin/env python3
"""Удаляет правила, которые не работают."""
import os
import json
import sqlite3

BASE = os.path.expanduser('~/quantum_lab')
MEM = os.path.join(BASE, 'tools/agent/memory.db')
RULES = os.path.join(BASE, 'tools/agent/rules.json')

def clean():
    try:
        c = sqlite3.connect(MEM)
        rows = c.execute("""SELECT action, AVG(score), COUNT(*) FROM experience
                            GROUP BY action HAVING COUNT(*) >= 3""").fetchall()
        c.close()
    except sqlite3.Error as e:
        print(f"Ошибка при работе с БД: {e}")
        return

    bad = [r for r, s, n in rows if s < -0.5 and n >= 3]
    if not bad: 
        return

    if os.path.exists(RULES):
        try:
            with open(RULES, 'r') as f:
                rules = json.load(f)
        except (IOError, json.JSONDecodeError) as e:
            print(f"Ошибка при загрузке файла правил: {e}")
            return

        new_rules = [r for r in rules if r.get('name') not in bad]
        
        if len(new_rules) < len(rules):
            try:
                with open(RULES, 'w') as f:
                    json.dump(new_rules, f, indent=2, ensure_ascii=False)
                print(f'✅ удалено правил: {len(rules) - len(new_rules)} ({bad})')
            except IOError as e:
                print(f"Ошибка при записи файла правил: {e}")
    else:
        print(f"Файл правил не найден: {RULES}")

if __name__ == '__main__':
    clean()