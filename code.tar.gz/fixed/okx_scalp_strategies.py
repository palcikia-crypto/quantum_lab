#!/usr/bin/env python3
"""okx_scalp_strategies.py — 7 скальпинг-стратегий по OBI / pressure / VWAP.
Каждая функция: (obi, pressure, spread, price, vwap_1m) -> 'LONG' / 'SHORT' / None."""

def validate_inputs(obi, pressure, spread, price, vwap_1m):
    """Проверяет корректность входных параметров.
    
    Аргументы:
        obi (float): Значение OBI.
        pressure (float): Значение давления.
        spread (float): Значение спреда.
        price (float): Текущая цена.
        vwap_1m (float): Значение VWAP за 1 минуту.

    Возвращает:
        bool: True, если все параметры корректны, иначе False.
    """
    return not (obi is None or pressure is None or vwap_1m is None or vwap_1m == 0)

def scalp_obi_long(obi, pressure, spread, price, vwap_1m):
    """Стратегия скальпирования на основе OBI для длинной позиции.
    
    Аргументы:
        obi (float): Значение OBI.
        pressure (float): Значение давления.
        spread (float): Значение спреда.
        price (float): Текущая цена.
        vwap_1m (float): Значение VWAP за 1 минуту.

    Возвращает:
        str или None: 'LONG', если условия выполнены, иначе None.
    """
    if obi is None: return None
    if obi > 0.4: return 'LONG'
    return None

def scalp_obi_short(obi, pressure, spread, price, vwap_1m):
    """Стратегия скальпирования на основе OBI для короткой позиции.
    
    Аргументы:
        obi (float): Значение OBI.
        pressure (float): Значение давления.
        spread (float): Значение спреда.
        price (float): Текущая цена.
        vwap_1m (float): Значение VWAP за 1 минуту.

    Возвращает:
        str или None: 'SHORT', если условия выполнены, иначе None.
    """
    if obi is None: return None