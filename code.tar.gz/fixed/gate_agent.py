#!/usr/bin/env python3
import os, json
from datetime import datetime
import requests

BASE = os.path.expanduser('~/quantum_lab')
GATE = os.path.join(BASE, 'data/gate_all.json')
REPORT = os.path.join(BASE, 'data/gate_report.json')
LOG = os.path.join(BASE, 'logs/gate_agent.log')

def log(m):
    line = f'[{datetime.now():%H:%M:%S}] {m}'
    print(line, flush=True)
    with open(LOG, 'a') as f: f.write(line+'\n')

def check_ai_availability():
    try:
        response = requests.get('https://api.example.com/health')  # Замените на реальный адрес ИИ
        return response.status_code == 200
    except requests.ConnectionError:
        log('ИИ недоступен (сеть)')
        return False

def main():
    log('=== GATE AGENT ===')
    if not check_ai_availability():
        return
    if os.path.exists(GATE):
        d = json.load(open(GATE))
        mtime = datetime.fromtimestamp(os.path.getmtime(GATE))
        age_h = (datetime.now() - mtime).total_seconds() / 3600
        result = {'summary': d.get('summary'), 'age_hours': round(age_h, 1), 'need': age_h > 2}
        log(f'check: {result}')
        with open(REPORT, 'w') as f: json.dump({'timestamp': datetime.now().isoformat(), 'result': result}, f, indent=2)
    else:
        log('gate_all.json нет')

if __name__ == '__main__': main()