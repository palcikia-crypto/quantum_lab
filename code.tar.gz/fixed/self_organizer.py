#!/usr/bin/env python3
"""self_organizer.py — событийная самоорганизация. Реагирует на изменения."""
import os
import sys
import time
import json
import logging
from datetime import datetime
from copy import deepcopy

BASE = os.path.expanduser('~/quantum_lab')
sys.path.insert(0, os.path.join(BASE, 'core'))
import brain

# Настройка логирования
logging.basicConfig(filename=os.path.join(BASE, 'logs/self_organizer.log'), level=logging.INFO, format='%(asctime)s %(message)s')

def log(m):
    logging.info(m)
    print(m, flush=True)

def main(sleep_time=120):
    log('=== SELF-ORGANIZER STARTED ===')
    brain.init_db()
    last_state = None
    while True:
        try:
            state = brain.get_full_state()
            # Реагируем на изменения режима рынка
            oracle = state.get('oracle', [])
            regimes = {o['symbol']: o['regime'] for o in oracle} if oracle else {}
            if last_state and last_state != regimes:
                changed = [s for s in regimes if s in last_state and regimes[s] != last_state[s]]
                if changed:
                    log(f'режим изменился: {changed}')
                    # здесь можно пересмотреть стратегии
            last_state = deepcopy(regimes)
        except Exception as e:
            logging.error(f'ERROR: {e}', exc_info=True)
        time.sleep(sleep_time)

if __name__ == '__main__':
    main()