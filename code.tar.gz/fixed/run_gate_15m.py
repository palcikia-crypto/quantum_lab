import sys
import os
import json
import logging
from datetime import datetime
from strategy_pool import STRATEGIES
from gate_v3 import run_gate

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

BASE = os.path.expanduser('~/quantum_lab')
pairs = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT']
tf = '15m'
model = 'current'  # для 15m — current (окно = 1-3 свечи)
results = []

def run_strategy(pair, name, fn):
    try:
        r = run_gate(pair, tf, name, fn, model=model, use_h1=True)
        if r and r['L1']['n'] >= 100:
            results.append(r)
        logging.info(f'{pair} {name} -> {r["verdict"] if r else "None"} n={r["L1"]["n"] if r else 0}')
    except Exception as e:
        logging.error(f'{pair} {name} ERROR: {e}')

def save_results():
    summary = {v: sum(1 for r in results if r['verdict'] == v) for v in ['GOLDEN', 'TRADE_NOW', 'WATCH', 'SKIP']}
    with open(f'{BASE}/data/gate_15m.json', 'w') as f:
        json.dump({'timestamp': datetime.now().isoformat(), 'summary': summary, 'results': results}, f, indent=2, ensure_ascii=False)
    
    logging.info(f'Прогонов: {len(results)}')
    logging.info(f'Summary: {summary}')
    for r in results[:15]:
        logging.info(f'{r["symbol"].ljust(10)} {r["strategy"].ljust(15)} {r["verdict"].ljust(10)} WR={r["L1"]["wr"]}% n={r["L1"]["n"]}')

for pair in pairs:
    for name, fn in STRATEGIES.items():
        run_strategy(pair, name, fn)

results.sort(key=lambda x: (-x['score'], -x['L1']['wr']))
save_results()