#!/usr/bin/env python3
"""regime_switcher.py — переключает стратегии при смене режима."""
import os
import json
import sqlite3
import time
from datetime import datetime

BASE = os.path.expanduser('~/quantum_lab')
LOG = os.path.join(BASE, 'logs/regime_switcher.log')
ORACLE = os.path.join(BASE, 'data/oracle.db')
ACTIVE = os.path.join(BASE, 'data/okx_active.json')
REGIME_FILE = os.path.join(BASE, 'data/okx_active_regime.json')
# Белый список: только стратегии, прошедшие 4/4 в stability_check_2
WHITELIST = {'okx_vwap_rev_7', 'okx_vwap_rev_13', 'okx_vwap_rev_15', 'okx_grid_sma_13', 'okx_grid_sma_15'}

def log(m):
    line = f'[{datetime.now():%H:%M:%S}] {m}'
    print(line, flush=True)
    with open(LOG, 'a') as f:
        f.write(line + '\n')

def get_regime(sym):
    if not os.path.exists(ORACLE):
        return None
    try:
        with sqlite3.connect(ORACLE, timeout=5) as c:
            r = c.execute("SELECT regime, adx FROM regime WHERE symbol=? ORDER BY ts DESC LIMIT 1", (sym,)).fetchone()
            return {'regime': r[0], 'adx': r[1]} if r else None
    except sqlite3.Error as e:
        log(f'Ошибка при работе с базой данных: {e}')
        return None

def load_json_file(file_path):
    if not os.path.exists(file_path):
        log(f'Файл не найден: {file_path}')
        return None
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        log(f'Ошибка при загрузке JSON файла {file_path}: {e}')
        return None

def save_json_file(file_path, data):
    try:
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
    except IOError as e:
        log(f'Ошибка при сохранении JSON файла {file_path}: {e}')