import sqlite3
import pandas as pd
import numpy as np

# Параметры
symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT']
timeframe = '4h'
tp = 0.02  # Take Profit 2%
sl = 0.01  # Stop Loss 1%
commission = 0.001  # Комиссия 0.1%

# Функция для расчета индикаторов
def calculate_indicators(df):
    # RSI
    delta = df['c'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['RSI'] = 100 - (100 / (1 + rs))

    # EMA
    df['EMA_20'] = df['c'].ewm(span=20, adjust=False).mean()
    df['EMA_50'] = df['c'].ewm(span=50, adjust=False).mean()

    return df

# Функция бэктестера
def backtest(symbol):
    conn = sqlite3.connect('data/market.db')
    query = f"SELECT * FROM candles WHERE symbol='{symbol}' AND timeframe='{timeframe}'"
    df = pd.read_sql(query, conn)
    conn.close()

    df = calculate_indicators(df)

    balance = 1000  # Начальный баланс
    position = 0  # Текущая позиция
    entry_price = 0

    for i in range(len(df)):
        if position == 0 and df['RSI'].iloc[i] < 30:  # Условие на покупку
            position = balance * (1 - commission) / df['c'].iloc[i]
            entry_price = df['c'].iloc[i]

        elif position > 0:  # Если есть позиция
            # Проверка на достижение TP или SL
            if df['c'].iloc[i] >= entry_price * (1 + tp):
                balance = position * df['c'].iloc[i] * (1 - commission)
                position = 0  # Закрываем позицию
            elif df['c'].iloc[i] <= entry_price * (1 - sl):
                balance =