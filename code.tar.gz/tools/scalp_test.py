import sqlite3

FEE = 0.001
LIMIT = 3000

def my_indicator(prices):
    def sma(data, period):
        if len(data) < period:
            return None
        return sum(data[-period:]) / period

    def ema(data, period):
        if len(data) < period:
            return None
        k = 2 / (period + 1)
        ema_value = sum(data[:period]) / period
        for price in data[period:]:
            ema_value = (price - ema_value) * k + ema_value
        return ema_value

    def williams(data, period):
        if len(data) < period:
            return None
        highest_high = max(data[-period:])
        lowest_low = min(data[-period:])
        return (highest_high - data[-1]) / (highest_high - lowest_low) * -100

    williams_values = [williams(prices[:i], 14) for i in range(1, len(prices) + 1)]
    return williams_values

def fetch(conn, sym):
    cur = conn.cursor()
    cur.execute("SELECT ts, o, h, l, c, v FROM candles WHERE symbol=? AND tf=? ORDER BY ts DESC LIMIT ?", (sym, "15m", LIMIT))
    return cur.fetchall()[::-1]

def bt(conn, sym):
    cs = fetch(conn, sym)
    if len(cs) < 30: return 0.0
    closes = [r[4] for r in cs]
    ind = my_indicator(closes)
    
    if not isinstance(ind, (list, tuple)):
        ind = [ind] * len(closes)
    
    if len(ind) < len(cs):
        ind = [None] * (len(cs) - len(ind)) + list(ind)
    elif len(ind) > len(cs):
        ind = list(ind)[-len(cs):]
    
    pos = 0
    entry = 0.0
    bars = 0
    trades = []
    
    for i in range(1, len(cs)):
        if ind[i] is None or ind[i-1] is None: continue
        ind_cur, ind_prev = ind[i], ind[i-1]
        prev_c, cur_c = closes[i-1], closes[i]
        high, low = cs[i][2], cs[i][3]
        
        if pos == 0 and prev_c < -80 and cur_c > -50:  # Условие LONG
            pos = 1
            entry = cur_c
        elif pos == 0 and prev_c > -20 and cur_c < -50:  # Условие SHORT
            pos = -1
            entry = cur_c
        
        if pos == 1:
            bars += 1
            if high >= entry * 1.005: trades.append(0.005 - FEE*2); pos = 0
            elif low <= entry * 0.997: trades.append(-0.003 - FEE*2); pos = 0
            elif bars >= 8:
                pnl = (cur_c - entry) / entry - FEE*2; trades.append(pnl); pos = 0
        elif pos == -1:
            bars += 1
            if low <= entry * 0.995: trades.append(0.005 - FEE*2); pos = 0
            elif high >= entry * 1.003: trades.append(-0.003 - FEE*2); pos = 0
            elif bars >= 8:
                pnl = (entry - cur_c) / entry - FEE*2; trades.append(pnl); pos = 0
    
    return sum(trades)

def main():
    conn = sqlite3.connect("data/market.db")
    total = 0.0
    for s in ["BTCUSDT","ETHUSDT","SOLUSDT","DOGEUSDT"]:
        total += bt(conn, s)
    print(f"ИТОГО: {total}")
    conn.close()

if __name__ == "__main__":
    main()
