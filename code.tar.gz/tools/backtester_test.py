import sqlite3
import math

def fetch_data(symbol, timeframe):
    conn = sqlite3.connect('data/market.db')
    cursor = conn.cursor()
    query = f"""
    SELECT ts, o, h, l, c, v 
    FROM candles 
    WHERE symbol = '{symbol}' AND timeframe = '{timeframe}'
    ORDER BY ts
    """
    cursor.execute(query)
    data = cursor.fetchall()
    conn.close()
    return data

def calculate_rsi(prices, period=14):
    gains = []
    losses = []
    for i in range(1, len(prices)):
        change = prices[i] - prices[i - 1]
        if change > 0:
            gains.append(change)
            losses.append(0)
        else:
            gains.append(0)
            losses.append(-change)

    avg_gain = sum(gains[-period:]) / period
    avg_loss = sum(losses[-period:]) / period if sum(losses[-period:]) != 0 else 1e-10

    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def backtest(symbol):
    data = fetch_data(symbol, '4h')
    prices = [row[4] for row in data]  # Closing prices
    rsi_values = []
    
    for i in range(14, len(prices)):  # Start calculating RSI after enough data
        rsi = calculate_rsi(prices[i-14:i])
        rsi_values.append(rsi)

    balance = 1000  # Starting balance
    position = 0
    commission_rate = 0.001
    tp = 0.02  # 2% Take Profit
    sl = 0.01  # 1% Stop Loss

    for i in range(len(rsi_values)):
        if rsi_values[i] < 30 and position == 0:  # Buy signal
            position = balance / prices[i + 14]  # Buy at the current price
            balance = 0  # Balance is now 0 after buying
        elif position > 0:
            current_price = prices[i + 14]
            # Check for Take Profit
            if current_price >= (1 + tp) * (prices[i + 14 - 1] *