import requests
import llmf

def ask(prompt: str, system_prompt: str = "Ты — эксперт по Python.") -> str:
    # Попытка 1: DeepSeek-V3 через llm7.io (отлично пишет код)
    try:
        headers = {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"}
        data = {
            "model": "deepseek-v3",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            "max_tokens": 4000,
            "temperature": 0.2
        }
        r = requests.post("https://api.llm7.io/v1/chat/completions", headers=headers, json=data, timeout=90)
        if r.status_code == 200:
            return r.json()["choices"][0]["message"]["content"]
    except Exception as e:
        print(f"   ⚠️ DeepSeek/llm7 сбой: {e}")

    # Попытка 2: llmf (на случай, если DeepSeek недоступен)
    try:
        r = llmf.chat(prompt, system=system_prompt, model="best", max_tokens=4000)
        return r.text
    except Exception as e:
        return f"ОШИБКА_API: Все модели недоступны ({e})"
