#!/usr/bin/env python3
"""Агент v3: память + адаптивные решения + автопереобучение."""
import os, sys, json, sqlite3, subprocess, time
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import memory, analytics

BASE = os.path.expanduser('~/quantum_lab')
AGENT_DIR = os.path.join(BASE, 'tools/agent')
RULES = os.path.join(AGENT_DIR, 'rules.json')
LOG = os.path.join(BASE, 'logs/agent.log')
STATE = os.path.join(AGENT_DIR, 'state.json')

def log(m):
    line = f'[{datetime.now():%H:%M:%S}] {m}'
    print(line, flush=True)
    with open(LOG, 'a') as f: f.write(line + '\n')

def load_state():
    if os.path.exists(STATE):
        try: return json.load(open(STATE))
        except: pass
    return {'last_retrain': 0, 'last_alert': 0}

def save_state(s):
    json.dump(s, open(STATE, 'w'))

def collect_facts():
    facts = {'ts': int(time.time())}
    for name in ['okx_bot_paper_v4', 'brain_loop', 'oracle.py', 'orderbook_oracle', 'evolve_agent']:
        r = subprocess.run(['pgrep', '-f', name], capture_output=True, text=True)
        facts[f'proc_{name}'] = bool(r.stdout.strip())
    for db, table in [('oracle.db', 'regime'), ('market.db', 'candles'), ('orderbook.db', 'orderbooks')]:
        try:
            c = sqlite3.connect(os.path.join(BASE, 'data', db))
            age = c.execute(f"SELECT (strftime('%s','now') - MAX(ts)) FROM {table}").fetchone()[0]
            c.close()
            facts[f'age_{db}'] = age
        except: facts[f'age_{db}'] = None
    try:
        c = sqlite3.connect(os.path.join(BASE, 'data/okx_paper_v4.db'))
        facts['pnl_total'] = c.execute("SELECT ROUND(SUM(pnl),2) FROM trades WHERE status='CLOSED'").fetchone()[0] or 0
        facts['pnl_24h'] = c.execute("SELECT ROUND(COALESCE(SUM(pnl),0),2) FROM trades WHERE status='CLOSED' AND closed_at > strftime('%s','now')-86400").fetchone()[0] or 0
        c.close()
    except: pass
    ml_path = os.path.join(BASE, 'data/ml_predictions_online.json')
    if os.path.exists(ml_path):
        try:
            d = json.load(open(ml_path))
            facts['ml_bad'] = [s for s, v in d.get('predictions', {}).items() if v['proba_long'] < 0.05 or v['proba_long'] > 0.95]
        except: facts['ml_bad'] = []
    return facts

def apply_rules(facts, rules):
    actions = []
    for rule in rules:
        cond = rule.get('condition', {})
        ok = True
        for k, v in cond.items():
            if k.endswith('_lt') and not (facts.get(k[:-3]) is not None and facts.get(k[:-3]) < v): ok = False
            elif k.endswith('_gt') and not (facts.get(k[:-3]) is not None and facts.get(k[:-3]) > v): ok = False
            elif k.endswith('_false') and not (facts.get(k[:-6]) is False): ok = False
            elif k.endswith('_true') and not (facts.get(k[:-5]) is True): ok = False
            elif not k.endswith(('_lt','_gt','_false','_true')) and facts.get(k) != v: ok = False
        if ok:
            actions.append(rule)
    return actions

def execute_action(action, facts, state):
    a = action.get('action')
    rule = action.get('name', action.get('reason', '?'))
    success = False
    try:
        if a == 'restart':
            proc = action['target']
            subprocess.run(['pkill', '-9', '-f', proc], capture_output=True)
            time.sleep(2)
            cmd = action.get('cmd', f'python3 -u core/{proc}.py')
            subprocess.Popen(cmd.split(), cwd=BASE, stdout=open(os.path.join(BASE, f'logs/{proc}.log'), 'a'), stderr=subprocess.STDOUT)
            log(f'🔧 restart {proc}')
            success = True
        elif a == 'retrain_ml':
            subprocess.Popen(['python3', 'core/ml_online_simple.py'], cwd=BASE, stdout=open(os.path.join(BASE, 'logs/ml_online.log'), 'a'), stderr=subprocess.STDOUT)
            log('🔧 retrain ML')
            state['last_retrain'] = int(time.time())
            success = True
        elif a == 'stop_v4':
            subprocess.run(['pkill', '-9', '-f', 'okx_bot_paper_v4'], capture_output=True)
            try:
                rp = os.path.join(AGENT_DIR, 'recovery.json')
                rs = json.load(open(rp)) if os.path.exists(rp) else {}
                rs['stopped_v4_at'] = int(time.time())
                json.dump(rs, open(rp, 'w'))
            except: pass
            log(f'🛑 STOP v4: {action.get("reason")}')
            with open(os.path.join(BASE, 'logs/agent_alerts.log'), 'a') as f:
                f.write(f'[{datetime.now()}] STOP v4: {action.get("reason")}\n')
            success = True
        elif a == 'alert':
            msg = action.get('message', action.get('reason', ''))
            log(f'🚨 ALERT: {msg}')
            with open(os.path.join(BASE, 'logs/agent_alerts.log'), 'a') as f:
                f.write(f'[{datetime.now()}] {msg}\n')
            success = True
        elif a == 'log':
            log(f'📝 {action.get("reason", "")}')
            success = True
    except Exception as e:
        log(f'❌ action error: {e}')
    memory.save_action(a, action.get('target', rule), 'ok' if success else 'fail', success)
    memory.update_rule_weight(rule, success)
    return success

def main():
    log('=== AGENT v3 RUN ===')
    memory.init()
    state = load_state()
    facts = collect_facts()
    for k, v in facts.items():
        memory.save_fact(k, v)
    # 1. Стандартные правила
    rules = json.load(open(RULES)) if os.path.exists(RULES) else []
    fired = apply_rules(facts, rules)
    for r in fired:
        execute_action(r, facts, state)
    # 2. Адаптивные решения
    adaptive = analytics.check_adaptive()
    for d in adaptive:
        execute_action(d, facts, state)
    # 3. Автопереобучение ML (раз в 24ч)
    if time.time() - state.get('last_retrain', 0) > 86400:
        execute_action({'action': 'retrain_ml', 'reason': '24ч с последнего переобучения'}, facts, state)
    save_state(state)
    try:
        import subprocess as _sp
        _sp.run(['python3', 'tools/agent/recovery.py'], cwd=BASE)
    except: pass
    stats = memory.stats()
    log(f'✅ run: правил {len(fired)+len(adaptive)}, память: {stats}')
    log('=== DONE ===')

if __name__ == '__main__':
    main()
