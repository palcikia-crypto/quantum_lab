import sqlite3

FEE = 0.001
LIMIT = 1000

def my_indicator(prices):
    result = [None] * len(prices)
    n = 14
    if len(prices) < n: return result

    def calculate_roc(prices, n):
        roc = [None] * len(prices)
        for i in range(n, len(prices)):
            if prices[i-n] == 0:
                roc[i] = None
            else:
                roc[i] = ((prices[i] - prices[i-n]) / prices[i-n]) * 100
        return roc

    result = calculate_roc(prices, n)
    return result

def normalize_ind(raw, length):
    if raw is None: return [None] * length
    if not isinstance(raw, (list, tuple)):
        try: return [float(raw)] * length
        except: return [None] * length
    cleaned = []
    for x in raw:
        if x is None: cleaned.append(None)
        elif isinstance(x, (int, float)): cleaned.append(float(x))
        elif isinstance(x, (list, tuple)) and len(x) > 0:
            try: cleaned.append(float(x[0]))
            except: cleaned.append(None)
        else: cleaned.append(None)
    if len(cleaned) < length: cleaned = [None] * (length - len(cleaned)) + cleaned
    elif len(cleaned) > length: cleaned = cleaned[-length:]
    return cleaned

def fetch(conn, sym):
    cur = conn.cursor()
    cur.execute("SELECT ts, o, h, l, c, v FROM candles WHERE symbol=? AND tf=? ORDER BY ts DESC LIMIT ?", (sym, "4h", LIMIT))
    return cur.fetchall()[::-1]

def bt(conn, sym):
    cs = fetch(conn, sym)
    if len(cs) < 30: return 0.0
    closes = [r[4] for r in cs]
    ind = normalize_ind(my_indicator(closes), len(cs))
    pos = 0
    entry = 0.0
    trades = []
    for i in range(1, len(cs)):
        if ind[i] is None or ind[i-1] is None: continue
        # 1. СНАЧАЛА закрываем существующую позицию
        if pos == 1:
            if cs[i][2] >= entry * 1.02: trades.append(0.02 - FEE*2); pos = 0; continue
            elif cs[i][3] <= entry * 0.99: trades.append(-0.01 - FEE*2); pos = 0; continue
        elif pos == -1:
            if cs[i][3] <= entry * 0.98: trades.append(0.02 - FEE*2); pos = 0; continue
            elif cs[i][2] >= entry * 1.01: trades.append(-0.01 - FEE*2); pos = 0; continue
        # 2. ПОТОМ проверяем вход
        if pos == 0:
            ind_cur = ind[i]
            ind_prev = ind[i-1]
            prev_c = closes[i-1]
            cur_c = closes[i]
            high = cs[i][2]
            low = cs[i][3]
            if pos == 0 and (ind_cur < 35 or (ind_cur > ind_prev and ind_cur > 35)):
                pos = 1
                entry = cur_c
            elif pos == 0 and (ind_cur > 65 or (ind_cur < ind_prev and ind_cur < 65)):
                pos = -1
                entry = cur_c
    return sum(trades)

def main():
    conn = sqlite3.connect("data/market.db")
    total = 0.0
    for s in ["BTCUSDT","ETHUSDT","SOLUSDT","DOGEUSDT","XRPUSDT"]:
        total += bt(conn, s)
    print(f"ИТОГО: {total}")
    conn.close()

if __name__ == "__main__":
    main()
