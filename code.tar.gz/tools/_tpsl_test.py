import sqlite3

FEE = 0.001
LIMIT = 1000
LONG_THR = -80
SHORT_THR = -20
TP_PCT = 0.05
SL_PCT = 0.0075

def my_indicator(prices):
    result = [None] * len(prices)
    n = 14
    if len(prices) < n: return result
    for i in range(n - 1, len(prices)):
        window = prices[i - n + 1:i + 1]
        hh = max(window)
        ll = min(window)
        if hh == ll: result[i] = -50.0
        else: result[i] = (hh - prices[i]) / (hh - ll) * -100
    return result

def fetch(conn, sym):
    cur = conn.cursor()
    cur.execute("SELECT ts, o, h, l, c, v FROM candles WHERE symbol=? AND tf=? ORDER BY ts DESC LIMIT ?", (sym, "4h", LIMIT))
    return cur.fetchall()[::-1]

def bt(conn, sym):
    cs = fetch(conn, sym)
    if len(cs) < 30: return 0.0
    closes = [r[4] for r in cs]
    ind = my_indicator(closes)
    pos = 0
    entry = 0.0
    trades = []
    for i in range(1, len(cs)):
        if ind[i] is None or ind[i-1] is None: continue
        ind_cur = ind[i]
        cur_c = closes[i]
        high = cs[i][2]
        low = cs[i][3]
        if pos == 0 and ind_cur < LONG_THR:
            pos = 1; entry = cur_c
        elif pos == 0 and ind_cur > SHORT_THR:
            pos = -1; entry = cur_c
        if pos == 1:
            if high >= entry * (1 + TP_PCT): trades.append(TP_PCT - FEE*2); pos = 0
            elif low <= entry * (1 - SL_PCT): trades.append(-SL_PCT - FEE*2); pos = 0
        elif pos == -1:
            if low <= entry * (1 - TP_PCT): trades.append(TP_PCT - FEE*2); pos = 0
            elif high >= entry * (1 + SL_PCT): trades.append(-SL_PCT - FEE*2); pos = 0
    return sum(trades)

def main():
    conn = sqlite3.connect("data/market.db")
    total = 0.0
    for s in ["BTCUSDT","ETHUSDT","SOLUSDT","DOGEUSDT","XRPUSDT"]:
        total += bt(conn, s)
    print(f"ИТОГО: {total}")
    conn.close()

if __name__ == "__main__":
    main()
