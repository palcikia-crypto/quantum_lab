import os
import zipfile
from datetime import datetime

class BackupManager:
    def __init__(self, data_folder='data', max_backups=10):
        self.data_folder = data_folder
        self.max_backups = max_backups
        self.backup_folder = 'backups'
        os.makedirs(self.backup_folder, exist_ok=True)

    def create_backup(self):
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_filename = f'backup_{timestamp}.zip'
        backup_path = os.path.join(self.backup_folder, backup_filename)

        with zipfile.ZipFile(backup_path, 'w') as zipf:
            for root, _, files in os.walk(self.data_folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    zipf.write(file_path, os.path.relpath(file_path, self.data_folder))

        self.manage_backups()

    def manage_backups(self):
        backups = sorted(os.listdir(self.backup_folder))
        while len(backups) > self.max_backups:
            oldest_backup = backups.pop(0)
            os.remove(os.path.join(self.backup_folder, oldest_backup))

def main():
    manager = BackupManager()
    manager.create_backup()

if __name__ == '__main__':
    main()