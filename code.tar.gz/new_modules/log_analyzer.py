import os
import re
from datetime import datetime, timedelta
from collections import defaultdict

class LogAnalyzer:
    def __init__(self, log_dir):
        self.log_dir = log_dir
        self.error_patterns = [
            r'ERROR',
            r'EXCEPTION',
            r'FATAL',
            r'CRITICAL'
        ]

    def is_recent(self, log_time):
        return log_time >= datetime.now() - timedelta(days=1)

    def parse_log_file(self, file_path):
        errors = defaultdict(int)
        with open(file_path, 'r') as file:
            for line in file:
                timestamp_match = re.search(r'\[(.*?)\]', line)
                if timestamp_match:
                    log_time_str = timestamp_match.group(1)
                    try:
                        log_time = datetime.strptime(log_time_str, '%Y-%m-%d %H:%M:%S')
                        if self.is_recent(log_time):
                            for pattern in self.error_patterns:
                                if re.search(pattern, line):
                                    errors[pattern] += 1
                    except ValueError:
                        continue
        return errors

    def analyze_logs(self):
        all_errors = defaultdict(int)
        for log_file in os.listdir(self.log_dir):
            if log_file.endswith('.log'):
                file_path = os.path.join(self.log_dir, log_file)
                file_errors = self.parse_log_file(file_path)
                for error_type, count in file_errors.items():
                    all_errors[error_type] += count
        return all_errors

    def top_errors(self, n=5):
        error_counts = self.analyze_logs()
        sorted_errors = sorted(error_counts.items(), key=lambda item: item[1], reverse=True)
        return sorted_errors[:n]

def main():
    log_analyzer = LogAnalyzer('logs')
    top_problems = log_analyzer.top_errors()
    for error_type, count in top_problems:
        print(f'{error_type}: {count}')

if __name__ == '__main__':
    main()