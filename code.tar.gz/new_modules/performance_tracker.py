import json
from datetime import datetime

class PerformanceTracker:
    def __init__(self, filename='performance.json'):
        self.filename = filename
        self.data = self.load_data()

    def load_data(self):
        try:
            with open(self.filename, 'r') as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def save_data(self):
        with open(self.filename, 'w') as file:
            json.dump(self.data, file, indent=4)

    def record_pnl(self, bot_name, pnl):
        date_str = datetime.now().strftime('%Y-%m-%d')
        if date_str not in self.data:
            self.data[date_str] = {}
        self.data[date_str][bot_name] = pnl
        self.save_data()

    def get_history(self):
        return self.data

def main():
    tracker = PerformanceTracker()
    while True:
        bot_name = input("Введите имя бота (или 'exit' для выхода): ")
        if bot_name.lower() == 'exit':
            break
        try:
            pnl = float(input("Введите PnL для бота: "))
            tracker.record_pnl(bot_name, pnl)
            print(f"Записан PnL для {bot_name}: {pnl}")
        except ValueError:
            print("Пожалуйста, введите корректное значение PnL.")

if __name__ == '__main__':
    main()