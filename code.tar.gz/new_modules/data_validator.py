import sqlite3
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO, filename='data_validation.log', format='%(asctime)s - %(levelname)s - %(message)s')

class DataValidator:
    def __init__(self, db_name):
        self.db_name = db_name

    def connect(self):
        return sqlite3.connect(self.db_name)

    def check_for_nulls(self):
        with self.connect() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM market WHERE price IS NULL")
            null_count = cursor.fetchone()[0]
            if null_count > 0:
                logging.warning(f'Найдены {null_count} записи с пустыми значениями цены.')

    def check_for_duplicates(self):
        with self.connect() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT item_id, COUNT(*) FROM market GROUP BY item_id HAVING COUNT(*) > 1")
            duplicates = cursor.fetchall()
            for item_id, count in duplicates:
                logging.warning(f'Найдены {count} дубликатов для item_id {item_id}.')

    def check_negative_prices(self):
        with self.connect() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM market WHERE price < 0")
            negative_count = cursor.fetchone()[0]
            if negative_count > 0:
                logging.warning(f'Найдены {negative_count} записи с отрицательной ценой.')
                cursor.execute("UPDATE market SET price = 0 WHERE price < 0")
                conn.commit()
                logging.info(f'Отрицательные цены исправлены.')

    def validate_data(self):
        self.check_for_nulls()
        self.check_for_duplicates()
        self.check_negative_prices()

def main():
    validator = DataValidator('market.db')
    validator.validate_data()

if __name__ == '__main__':
    main()