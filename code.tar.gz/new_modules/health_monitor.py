import subprocess
import psutil
import time

PROCESSES = ['okx_bot_paper_v3.py', 'oracle.py', 'orderbook_oracle.py']

def is_process_running(process_name):
    """Проверяет, запущен ли процесс с заданным именем."""
    for proc in psutil.process_iter(['name']):
        if process_name in proc.info['name']:
            return True
    return False

def restart_process(process_name):
    """Перезапускает процесс с заданным именем."""
    print(f"Перезапуск {process_name}...")
    subprocess.Popen(['python', process_name])

def check_processes():
    """Проверяет состояние всех процессов и перезапускает неактивные."""
    for process in PROCESSES:
        if not is_process_running(process):
            restart_process(process)

def main():
    while True:
        check_processes()
        time.sleep(10)  # Проверять каждые 10 секунд

if __name__ == '__main__':
    main()